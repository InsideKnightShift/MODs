mission "Really New RPG"
{
    state Initialize()
    
#include "..\Campaigns\Common.ech"

	consts
	{
		bufferGoals        =   16;                                              //
		bufferBringArts    =   48;                                              //
		bufferQuestNames   =  128;                                              //
		bufferMissionName  =  255;                                              //
		bufferPrizeNames   =  256;                                              //

		maskDefinedPrize   = 2048;                                              //
	}

	int iAllowed_RPG_BONUS[];                                                   //
	int iAllowed_RPG_HEALING[];                                                 //
	int iAllowed_RPG_HIRELING[];                                                //
	int iAllowed_RPG_MANA[];                                                    //
	int iAllowed_RPG_SHOP[];                                                    //
	int iAllowed_RPG_TELEPORT[];                                                //
	int iAllowed_RPG_QUEST[];                                                   //
	int iAllowed_RPG_QUEST_GIVER[];                                             //

	int iGiverUsed[];                                                           //

	function int iCountHeroesInventory(string sArtName);                        //

    #include "RPG-Shop.ech"
    #include "RPG-Bonus.ech"
    #include "RPG-Quests.ech"
    #include "RPG-Prizes.ech"
    #include "RPG-Monsters.ech"
    #include "RPG-Objects.ech"
    #include "RPG-Hireling.ech"

    #define INTERFACE_BORDERS_SIZE  15
	#define INTERFACE_BORDERS_COLOR 0xFF000000

    //Player
	player pNeutral;                                                            //NPCs
    player pNeutral1;                                                           //?!?
	player pNeutral2;                                                           //?!?
	player pEnemy;                                                              //Gegner
	
    //Units
	unitex auHero[];                                                            //Helden
	unitex auHeroReady[];                                                       //?!?
    unitex auHeroDepot[];                                                       //?!?
	unitex auPlayerHeroSmoke[];                                                 //?!?
	unitex auQuestHero[];                                                       //?!?
	unitex auTalker[];                                                          //Personen, welche sprechen (?)
	unitex auTalkerSmoke[];                                                     //?!?
	unitex auEscort[];                                                          //?!?
	unitex auEscortTo[];                                                        //Person, zu welcher hineskortiert werden soll (?)
	unitex auSpecial[];                                                         //?!?
	
	platoon apGuard[];                                                          //Wachenplatoons
	platoon apEnemy[];                                                          //Gegnerplatoons
	platoon apSpacial[];                                                        //?!?
	platoon apEscort[];                                                         //Eskortenplatoons


	
    //Variablen
                                                                                //----------Beginn: Unitvariablen
                                                                                
	int aiPlayerHeroX[];                                                        //Position der Helden (?)
	int aiPlayerHeroY[];                                                        //
	int aiPlayerHeroZ[];                                                        //    
    
	int aiEmemyX[];                                                             //Position der Gegner (?)
	int aiEmemyY[];                                                             //
	int aiEmemyZ[];                                                             //
 
	int aiNoEnemyX[];                                                           //?!?
	int aiNoEnemyY[];                                                           //
	int aiNoEnemyZ[];                                                           //
	int abNoEnemy[];                                                            //
 
	int aiBonusX[];                                                             //?!?
	int aiBonusY[];                                                             //
	int aiBonusZ[];                                                             //          

	int aiKilledX[];                                                            //Position von get�teten Gegnern (?)
	int aiKilledY[];                                                            //
	int aiKilledZ[];                                                            //	
                                                                                 
                                                                                //----------Ende: Unitvariablen
                                                                                //----------Beginn: Questvariablen
                                                                                
	int aiQuestType[];                                                          //
	
	int aiQuestReady[];                                                         //
	int aiQuestActive[];                                                        //
	int aiQuestDone[];                                                          //
	
	int aiPlayerQuest[];                                                        //
	int aiPlayerQuestsDone[];                                                   //
	int aiPlayerUnitsDestroyed[];                                               //
	int aiPlayerLastGoal[];                                                     //
	
	int aiQuestGiver[];                                                         //
    int aiQuestGiverX[];                                                        //Position von Questgebern (?)
	int aiQuestGiverY[];                                                        //
	int aiQuestGiverZ[];                                                        //
	int aiQuestGiverA[];                                                        //?!?

  	int aiQuestX[];                                                             //Position der Quests (?)
	int aiQuestY[];                                                             //
	int aiQuestZ[];                                                             //
	int aiQuestA[];                                                             //?!?

	int aiQuestGuardX[];                                                        //Gegner bei dem Quest (?)
	int aiQuestGuardY[];                                                        //
	int aiQuestGuardZ[];                                                        //
	int aiQuestGuardA[];                                                        //?!?

                                                                                //-----------Ende: Qestvariablen

    int aiStopTalk[];                                                           //
	int aiExGoalToGoalMap[];                                                    //
	int aiBringCount[];                                                         //
	int aiSafeArea[];                                                           //
	int iEscortMarkerTick;                                                      //
	int bAutoUpdateStats;                                                       //
	int iRespawnOneOf;                                                          //
	int iNoEnemyTrigerRange;                                                    //


	unitex auGate[];                                                            //
	unitex auQuestGate[];                                                       //
	unitex auQuestDoneGate[];                                                   //

	unitex auShop[];                                                            //
	unitex auHireling[];                                                        //

	unitex auShopSmoke[];                                                       //
	unitex auHirelingSmoke[];                                                   //


	int iHirelingLimit;                                                         //
	int iPassivePrizeProbModifier;                                              //
	int iPassivePrizeMonsterProbModifier;                                       //

	int aiPlayerRespawnX[];                                                     //Position des Respawn-Punktes (?)
	int aiPlayerRespawnY[];                                                     //
	int aiPlayerRespawnZ[];                                                     //
		

	consts
	{
		//Player
		playerNeutral1         =    8;                                          //
		playerNeutral2         =    9;                                          //
		playerEnemy            =   10;                                          //
		playerAnimals          =   14;                                          //

		//Variablen
		maskGateOpenSwitch     = 1024;                                          //
		dataLastArtifact       =   16;                                          //
		dataMovementMode       =   17;                                          //
		dataHeroExp            =   19;                                          //

		//Parameter
		rangeFollow            =   16;                                          //
		rangeNear              =    4;                                          //
		rangeTalk              =    1;                                          //
		rangeStartTalk         =    8;                                          //
		rangeSee               =   20;                                          //
		rangeSafe              =   15;                                          //
		rangeSafeRespawn       =    6;                                          //
		rangeShowArea          =    8;                                          //
		rangeCameraFollow      =    6;                                          //
		constMarkerUpdateTicks =    5;                                          //
		constWorkingTickTime   =   20;                                          //
		constFirstQuest        =    0;                                          //
		constLastQuest         =  255;                                          //
		constMaxPlayers        =    8;                                          //
		constQuestScore        =   25;                                          //
		constExpDivScore       =   10;                                          //

		constFirstGoal         =  16;                                           //
		

	enum comboRespawnMonsters
	{
		"translateQuestsDifficultyEasy",   // 0 // na Enemy tyle co graczy
		"translateQuestsDifficultyMedium", // 1 // + 1 
		"translateQuestsDifficultyHard",   // 2 // + 2
	multi:
		"translateQuestsDifficulty"
	}
    enum comboDropSubObjects
    {
        "translateDropRPGSubObjectsNo",
        "translateDropRPGSubObjectsYes",
    multi:
        "translateDropRPGSubObjects"
    }
     
    
    
    
    
	state Initialize
	{
		player pPlayer, pRest;
		int i, n;
		int j;
		unitex uShopUnit, uHero, uTeleport, uHirelingUnit;
		unitex auTeleports[];
		int anQuests[];
		int nQuest;
		int x, y, z, a;
		int nExp;
		int nSquad;
		int nRandNum;
		int bIsMagInGame;

		int nQuestArraySize;

		iHirelingLimit = 2;
		iPassivePrizeProbModifier = 0;
		iPassivePrizeMonsterProbModifier = 0;

		iAddToMonstersLevel = 0;

		TRACEF("Initialize...\n");
		TRACE1("Initialize RPG");
		
		auHero.Create(0);
		auHeroReady.Create(0);
        auHeroDepot.Create(16);
        for (i = 0; i < 16; ++i)
        {
            m_auHeroDepot[i] = null;
        }
		aiQuestReady.Create(0);
		aiQuestActive.Create(0);
		aiQuestDone.Create(0);
		
		aiKilledX.Create(0);
		aiKilledY.Create(0);
		aiKilledZ.Create(0);
		
		aiSafeArea.Create(0);

		auShop.Create(0);
		auHireling.Create(0);

		auShopSmoke.Create(0);
		auHirelingSmoke.Create(0);
                                                                                //---------- Initialisieren der Arrays nach Questgr��e
		iQuestArraySize = constQuests;
		
		auQuestHero.Create(iQuestArraySize);
		auTalker.Create(iQuestArraySize);
		auTalkerSmoke.Create(iQuestArraySize);
		apGuard.Create(iQuestArraySize);
		apEnemy.Create(iQuestArraySize);
		apSpacial.Create(iQuestArraySize);
		auEscort.Create(iQuestArraySize);
		apEscort.Create(iQuestArraySize);
		auEscortTo.Create(iQuestArraySize);
		anQuestType.Create(iQuestArraySize);
		anQuestGiver.Create(iQuestArraySize);
		auSpecial.Create(iQuestArraySize);
		abStopTalk.Create(iQuestArraySize);
		abGiverUsed.Create(iQuestArraySize);
		
		aiQuestGiverX.Create(nQuestArraySize);
		aiQuestGiverY.Create(nQuestArraySize);
		aiQuestGiverZ.Create(nQuestArraySize);
		aiQuestGiverA.Create(nQuestArraySize);

		aiQuestX.Create(nQuestArraySize);
		aiQuestY.Create(nQuestArraySize);
		aiQuestZ.Create(nQuestArraySize);
		aiQuestA.Create(nQuestArraySize);

		aiQuestGuardX.Create(nQuestArraySize);
		aiQuestGuardY.Create(nQuestArraySize);
		aiQuestGuardZ.Create(nQuestArraySize);
		aiQuestGuardA.Create(nQuestArraySize);

		auGate.Create(nQuestArraySize);
		auQuestGate.Create(nQuestArraySize);
		auQuestDoneGate.Create(nQuestArraySize);

		aiExGoalToGoalMap.Create(nQuestArraySize);

		aiBringCount.Create(nQuestArraySize);

		aiPlayerQuest.Create(constMaxPlayers);
		aiPlayerHeroX.Create(constMaxPlayers);
		aiPlayerHeroY.Create(constMaxPlayers);
		aiPlayerHeroZ.Create(constMaxPlayers);
		
		aiPlayerRespawnX.Create(constMaxPlayers);
		aiPlayerRespawnY.Create(constMaxPlayers);
		aiPlayerRespawnZ.Create(constMaxPlayers);

		aiPlayerQuestsDone.Create(constMaxPlayers);
		aiPlayerUnitsDestroyed.Create(constMaxPlayers);
		
		aiNoEnemyX.Create(constMaxPlayers);
		aiNoEnemyY.Create(constMaxPlayers);
		aiNoEnemyZ.Create(constMaxPlayers);
		abNoEnemy.Create(constMaxPlayers);
		
		aiPlayerLastGoal.Create(constMaxPlayers);
		
		auPlayerHeroSmoke.Create(constMaxPlayers);
		
		SetExperienceParams("EXPERIENCE_RPG_PARAM0");                           //Was das?
		
		// InitializePlayers();
		// InitializeUnits();

		aiEnemyX.Create(0);
		aiEnemyY.Create(0);
		aiEnemyZ.Create(0);

		aiBonusX.Create(0);
		aiBonusY.Create(0);
		aiBonusZ.Create(0);

		aiAllowed_RPG_BONUS.Create(0);
		aiAllowed_RPG_HEALING.Create(0);
		aiAllowed_RPG_HIRELING.Create(0);
		aiAllowed_RPG_MANA.Create(0);
		aiAllowed_RPG_SHOP.Create(0);
		aiAllowed_RPG_TELEPORT.Create(0);
		aiAllowed_RPG_QUEST.Create(0);
		aiAllowed_RPG_QUEST_GIVER.Create(0);

		for ( i=1; i<=66; ++i ) m_anAllowed_RPG_BONUS.Add(i);
		for ( i=1; i<=56; ++i ) m_anAllowed_RPG_HEALING.Add(i);
		for ( i=1; i<=18; ++i ) m_anAllowed_RPG_HIRELING.Add(i);
		for ( i=1; i<=56; ++i ) m_anAllowed_RPG_MANA.Add(i);
		for ( i=1; i<=21; ++i ) m_anAllowed_RPG_SHOP.Add(i);
		for ( i=1; i<=20; ++i ) m_anAllowed_RPG_TELEPORT.Add(i);
		for ( i=1; i<=80; ++i ) m_anAllowed_RPG_QUEST.Add(i);
		for ( i=1; i<=80; ++i ) m_anAllowed_RPG_QUEST_GIVER.Add(i);

		pNeutral  = GetPlayer( 8);                                              //?!?!?!?!?!?!
		pNeutral1 = GetPlayer( 8);
		pNeutral2 = GetPlayer( 9);

		pEnemy    = GetPlayer(10);

		SetNeutrals(pNeutral1, pEnemy);
		SetNeutrals(pNeutral2, pEnemy);

		if ( GetPlayer(playerAnimals) != null )
		{
			SetNeutrals(pNeutral1, GetPlayer(playerAnimals));                   //Warum ist player Animal nirgens definiert?
			SetNeutrals(pNeutral2, GetPlayer(playerAnimals));
		}
		
		SetNeutrals(pNeutral1, pNeutral2);

		EnableAssistant(0xffffff, false);                                       //Was das?

		auTeleports.Create(0);
		anQuests.Create(0);
		
		
		
		
		SetAllBridgesImmortal(true);
		{ iRespawnOneOf = 5; iNoEnemyTrigerRange = 30; }



		InitializeQuests();

		bIsMagInGame = false;                                                   //Was das?

		for(i=0; i < 8; i++)                                                    //Initialisieren der Spieler (?)
		{
			pPlayer=GetPlayer(i);
			if(pPlayer != null)
			{
				pPlayer.EnableAIFeatures(aiBNSendResult, false);
				pPlayer.EnableStatistics(false);
                pPlayer.SetDropSubObjectsOnKill(comboDropSubObjects);

                if (pPlayer.IsAlive())
                {
                    if (PointExist("MARKER_CHEST_DEPOT", i))
                    {
                        auHeroDepot[i] = pPlayer.CreateDepot(m_auHeroDepot[i], "CHEST_DEPOT", GetPointX("MARKER_CHEST_DEPOT", i), GetPointY("MARKER_CHEST_DEPOT", i), GetPointZ("MARKER_CHEST_DEPOT", i), GetPointAlpha("MARKER_CHEST_DEPOT", i));
                    }
				    uHero = pPlayer.CreateRPGCharacter(pPlayer.GetStartingPointX(),pPlayer.GetStartingPointY(),0,0);

				    m_anPlayerHeroX[i] = uHero.GetLocationX();
				    m_anPlayerHeroY[i] = uHero.GetLocationY();
				    m_anPlayerHeroZ[i] = uHero.GetLocationZ();

				    SetRespawnHere(uHero);

				    m_auHero.Add(uHero);
				    m_auHeroReady.Add(uHero);
				    
				    pPlayer.SelectUnit(uHero, false);

				    if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();

				    if ( uHero.GetMaxMagic() > 0 ) bIsMagInGame = true;
                }
                else
                {
		            aiPlayerRespawnX[i] = -1;
		            aiPlayerRespawnY[i] = -1;
		            aiPlayerRespawnZ[i] = -1;
                }

				pPlayer.SetScriptData(dataLastArtifact, -1);
				

	           pPlayer.SetScriptData(dataQuestMarker, -1);

				
				pPlayer.SetScriptData(dataHeroExp, 0);

				aiPlayerQuest[i] = -1;
				

	           pPlayer.EnableGoal(goalFindQuest, true);


				SetNeutrals(pPlayer, m_pNeutral1);
				SetNeutrals(pPlayer, m_pNeutral2);

				for ( j=i+1; j<8; ++j )
				{
					p2 = GetPlayer(j);
					
					if ( p2 != null )
					{
						if ( pPlayer.IsEnemy(p2) || p2.IsEnemy(pPlayer) ) SetNeutrals(pPlayer, p2);
					}
				}
			}
		}


		for ( i=0; i<constQuests; ++i )
		{
			if ( GetMinLevel(i) > nExp || GetMaxLevel(i) < nExp )
			{
				m_abGiverUsed[i] = true;
			}
		}

		for ( i=constFirstQuest; i<=constLastQuest; ++i )
		{
			if ( PointExist("MARKER_SHOP", i) )
			{
				if ( m_auHireling.GetSize() < m_nHirelingLimit && RAND(3) == 0 )
				{
					LOAD_ALLOWED("MARKER_SHOP", i, RPG_HIRELING)

					uHirelingUnit = GetUnit(GetPointX("MARKER_SHOP", i), GetPointY("MARKER_SHOP", i), GetPointZ("MARKER_SHOP", i));

					if ( uHirelingUnit != null )
					{
						InitializeHireling(uHirelingUnit);

						m_auHireling.Add(uHirelingUnit);
						m_auHirelingSmoke.Add(CreateSmokeObject(uHirelingUnit, "TALK_HIRE"));
					}
					else __ASSERT_FALSE();
				}
				else
				{
					LOAD_ALLOWED("MARKER_SHOP", i, RPG_SHOP)

					uShopUnit = GetLoadedShopUnit(m_pNeutral);

					if ( uShopUnit != null )
					{
						uShopUnit.SetSoldParams( 50, -100);
						uShopUnit.SetBuyParams (-50,  100);

						for ( j=1; j<=6; ++j )
						{
							if ( uShopUnit.GetShopType() == j ) { uShopUnit.SetArtefactBuyPriceModifier (j,  25-10+RAND(21)); uShopUnit.SetArtefactSoldPriceModifier (j, -25-10+RAND(21)); }
							if ( uShopUnit.GetShopType() != j ) { uShopUnit.SetArtefactBuyPriceModifier (j, -25-10+RAND(21)); uShopUnit.SetArtefactSoldPriceModifier (j,  25-10+RAND(21)); }
						}

						uShopUnit.SetArtefactBuyPriceModifier (7, -98);
						uShopUnit.SetArtefactSoldPriceModifier(7, -33);

						SetRealImmortal(uShopUnit, true);
						uShopUnit.CommandSetMovementMode(modeHoldPos);

						InitializeShop(uShopUnit, 8);

						m_auShop.Add(uShopUnit);
						m_auShopSmoke.Add(CreateSmokeObject(uShopUnit, "TALK_SHOP"));
					}
					else __ASSERT_FALSE();
				}
			}
			LOAD_ALLOWED("MARKER_BONUS", i, RPG_BONUS)
			if ( PointExist("MARKER_BONUS", i) )
			{
				x = GetPointX("MARKER_BONUS", i);
				y = GetPointY("MARKER_BONUS", i);
				z = GetPointZ("MARKER_BONUS", i);

				m_anBonusX.Add( x );
				m_anBonusY.Add( y );
				m_anBonusZ.Add( z );
			}
			if ( bIsMagInGame || IsAllowDynamicConnection())
			{
				LOAD_ALLOWED("MARKER_HEALING", i, RPG_MANA)
			}
			else
			{
				LOAD_ALLOWED("MARKER_HEALING", i, RPG_HEALING)
			}
			LOAD_ALLOWED("MARKER_TELEPORT", i, RPG_TELEPORT)
			if ( PointExist("MARKER_TELEPORT", i) )
			{
				auTeleports.Add(GetLoadedTeleport(m_pNeutral));
			}
			else
			{
				n = auTeleports.GetSize();
				if ( n > 1 ) for (j=0; j<n; ++j)
				{
					uTeleport = auTeleports[j];
					nRandNum = RAND(n-1);
					if ( nRandNum == j ) nRandNum = n-1;
					uTeleport.SetTeleportDestination(auTeleports[nRandNum]);
				}
				auTeleports.RemoveAll();
			}
			if ( PointExist("MARKER_ENEMY", i) )
			{
				x = GetPointX("MARKER_ENEMY", i);
				y = GetPointY("MARKER_ENEMY", i);
				z = GetPointZ("MARKER_ENEMY", i);
				m_anEnemyX.Add( x );
				m_anEnemyY.Add( y );
				m_anEnemyZ.Add( z );
			}
			if ( PointExist("MARKER_GATE_SPECIAL", i) )
			{
				x = GetPointX("MARKER_GATE_SPECIAL", i);
				y = GetPointY("MARKER_GATE_SPECIAL", i);
				z = GetPointZ("MARKER_GATE_SPECIAL", i);

				m_auQuestDoneGate[i] = GetUnit(x, y, z);
			}
			if ( PointExist("MARKER_QUEST_GIVER", i) && PointExist("MARKER_QUEST", i) )
			{
				x = GetPointX("MARKER_QUEST_GIVER", i);
				y = GetPointY("MARKER_QUEST_GIVER", i);
				z = GetPointZ("MARKER_QUEST_GIVER", i);
				a = GetPointAlpha("MARKER_QUEST_GIVER", i);

				m_anQuestGiverX[i] = x;
				m_anQuestGiverY[i] = y;
				m_anQuestGiverZ[i] = z;
				m_anQuestGiverA[i] = a;

				anQuests.Add(i);
			}
			else
			{
				j = i - 1;
				while ( anQuests.GetSize() > 0 )
				{
					nRandNum = RAND(anQuests.GetSize());
					nQuest = anQuests[nRandNum];

					anQuests.RemoveAt(nRandNum);

					x = GetPointX("MARKER_QUEST", nQuest);
					y = GetPointY("MARKER_QUEST", nQuest);
					z = GetPointZ("MARKER_QUEST", nQuest);
					a = GetPointAlpha("MARKER_QUEST", nQuest);

					m_anQuestX[j] = x;
					m_anQuestY[j] = y;
					m_anQuestZ[j] = z;
					m_anQuestA[j] = a;

					if ( a == 0 )
					{
						m_anQuestGuardX[j] = x;
						m_anQuestGuardY[j] = y - 6;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 64 )
					{
						m_anQuestGuardX[j] = x + 6;
						m_anQuestGuardY[j] = y;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 128 )
					{
						m_anQuestGuardX[j] = x;
						m_anQuestGuardY[j] = y + 6;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 192 )
					{
						m_anQuestGuardX[j] = x - 6;
						m_anQuestGuardY[j] = y;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else __ASSERT_FALSE();

					CreateQuest(j, CreateGiver(j));

					--j;
				}
				ASSERT( anQuests.GetSize() == 0 );
			}
			if ( PointExist("MARKER_GATE", i) )
			{
				x = GetPointX("MARKER_GATE", i);
				y = GetPointY("MARKER_GATE", i);
				z = GetPointZ("MARKER_GATE", i);

				m_auGate[i] = GetUnit(x, y, z);

				if ( PointExist("MARKER_SWITCH", i) )
				{
					CloseGate(i);

					x = GetPointX("MARKER_SWITCH", i);
					y = GetPointY("MARKER_SWITCH", i);
					z = GetPointZ("MARKER_SWITCH", i);

					CreateArtefact("SWITCH_1_1", x, y, z, maskGateOpenSwitch|i);
				}
				else
				{
					OpenGate(i);
				}
			}
		}

		// InitializeQuests(constFirstQuest, constLastQuest);
		#ifndef RPG_X_EC
			UpdateFindQuestGoal();
		#endif

		SetTimer(0, 10);
		SetTimer(1, 5*60*20);

		SetTimer(4, 1200);

        SetTimer(7, GetWindTimerTicks());
		StartWind();
		
		#ifdef RPG_X_EC
			RPGX_Start();
		#endif RPG_X_EC

		TRACEF("Working...\n");

		#ifdef RPGX_START_CUTSCENE
			return StartCutscene, 0;
		#endif

		return Working;
	}


}
