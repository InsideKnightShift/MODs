// #define PRIZE_PROB_TEST
// #define QUESTS_TEST

mission "New RPG"
{
#include "..\Campaigns\Common.ech"

	consts
	{
		bufferGoals        =   16;
		bufferBringArts    =   48;
		bufferQuestNames   =  128;
		bufferMissionName  =  255;
		bufferPrizeNames   =  256;

		maskDefinedPrize   = 2048;
	}

	int m_anAllowed_RPG_BONUS[];
	int m_anAllowed_RPG_HEALING[];
	int m_anAllowed_RPG_HIRELING[];
	int m_anAllowed_RPG_MANA[];
	int m_anAllowed_RPG_SHOP[];
	int m_anAllowed_RPG_TELEPORT[];
	int m_anAllowed_RPG_QUEST[];
	int m_anAllowed_RPG_QUEST_GIVER[];

	int m_abGiverUsed[];       // *

	function int CountHeroesInventory(string strArtName);

#include "RPG-Shop.ech"
#include "RPG-Bonus.ech"
#include "RPG-Quests.ech"
#include "RPG-Prizes.ech"
#include "RPG-Monsters.ech"
#include "RPG-Objects.ech"
#include "RPG-Hireling.ech"
#ifdef RPG_X_EC
#include "RPG_Declare.ech"
#endif RPG_X_EC

		#define INTERFACE_BORDERS_SIZE  15
		#define INTERFACE_BORDERS_COLOR 0xFF000000

	// players ->
		player m_pNeutral1;
		player m_pNeutral2;
		player m_pEnemy;
	// units ->
		unitex m_auHero[];
		unitex m_auHeroReady[];
        unitex m_auHeroDepot[];//03-10-31
		unitex m_auPlayerHeroSmoke[];
		unitex m_auQuestHero[];    // *
		unitex m_auTalker[];       // *
		unitex m_auTalkerSmoke[];  // *
		platoon m_apGuard[];       // *
		platoon m_apEnemy[];       // *
		platoon m_apSpacial[];     // *
		unitex m_auEscort[];       // *
		platoon m_apEscort[];      // *
		unitex m_auEscortTo[];     // *
		unitex m_auSpecial[];      // *
	// vars ->
		int m_anQuestType[];       // *
		int m_anQuestGiver[];      // *
		int m_abStopTalk[];        // *
		int m_anExGoalToGoalMap[]; // *
		int m_anBringCount[];      // *
		int m_anQuestReady[];
		int m_anQuestActive[];
		int m_anQuestDone[];
		int m_anKilledX[];
		int m_anKilledY[];
		int m_anKilledZ[];
		int m_anNoEnemyX[];
		int m_anNoEnemyY[];
		int m_anNoEnemyZ[];
		int m_abNoEnemy[];
		int m_anSafeArea[];
		int m_anPlayerHeroX[];
		int m_anPlayerHeroY[];
		int m_anPlayerHeroZ[];
		int m_anPlayerQuest[];
		int m_anPlayerQuestsDone[];
		int m_anPlayerUnitsDestroyed[];
		int m_anPlayerLastGoal[];
		int m_nEscortMarkerTick;
		#ifndef RPG_X_EC
			int m_nQuestMarkerTick;
		#endif
		int m_bAutoUpdateStats;
		int m_nRespawnOneOf;
		int m_nNoEnemyTrigerRange;
		#ifdef DEBUG
		int m_nDebugConsoleTick;
		#endif

		int m_anQuestGiverX[];
		int m_anQuestGiverY[];
		int m_anQuestGiverZ[];
		int m_anQuestGiverA[];

		int m_anQuestX[];
		int m_anQuestY[];
		int m_anQuestZ[];
		int m_anQuestA[];

		int m_anQuestGuardX[];
		int m_anQuestGuardY[];
		int m_anQuestGuardZ[];
		int m_anQuestGuardA[];

		unitex m_auGate[];
		unitex m_auQuestGate[];
		unitex m_auQuestDoneGate[];

		unitex m_auShop[];
		unitex m_auHireling[];

		unitex m_auShopSmoke[];
		unitex m_auHirelingSmoke[];

	player m_pNeutral;

	int m_anEnemyX[];
	int m_anEnemyY[];
	int m_anEnemyZ[];

	int m_anBonusX[];
	int m_anBonusY[];
	int m_anBonusZ[];

	int m_nHirelingLimit;
	int m_nPassivePrizeProbModifier;
	int m_nPassivePrizeMonsterProbModifier;

	int m_nAddToMonstersLevel;

	int m_anPlayerRespawnX[];
	int m_anPlayerRespawnY[];
	int m_anPlayerRespawnZ[];

	consts
	{
		// players ->
		playerNeutral1 =  8;
		playerNeutral2 =  9;
		playerEnemy    = 10;
		playerAnimals  = 14;

		// quests ->
		#ifndef RPG_X_EC
			goalFindQuest = 0;
		#endif

		// vars ->
		maskGateOpenSwitch  = 1024;
		dataLastArtifact    =   16;
		dataMovementMode    =   17;
		#ifndef RPG_X_EC
			dataQuestMarker =   18;
		#endif
		dataHeroExp         =   19;

		// params ->
		rangeFollow            =  16;
		rangeNear              =   4;
		rangeTalk              =   1;
		rangeStartTalk         =   8;
		rangeSee               =  20;
		rangeSafe              =  15;
		rangeSafeRespawn       =   6;
		rangeShowArea          =   8;
		rangeCameraFollow      =   6;
		constMarkerUpdateTicks =   5;
		#ifndef RPG_X_EC
			constQuestMarkerTicks  =  30;
		#endif
		constWorkingTickTime   =  20;
		constFirstQuest        =   0;
		constLastQuest         = 255;
		constMaxPlayers        =   8;
		constQuestScore        =  25;
		constExpDivScore       =  10;

		constFirstGoal         =  16;
		/*
		#ifdef RPG_X_EC
			constMaxGoals      =   3;
		#else
			constMaxGoals      =   8;
		#endif
		/**/
	}

	/**/
	enum comboRespawnMonsters
	{
		"translateQuestsDifficultyEasy",   // 0 // na Enemy tyle co graczy
		"translateQuestsDifficultyMedium", // 1 // + 1 
		"translateQuestsDifficultyHard",   // 2 // + 2
	multi:
		"translateQuestsDifficulty"
	}
    enum comboDropSubObjects
    {
        "translateDropRPGSubObjectsNo",
        "translateDropRPGSubObjectsYes",
    multi:
        "translateDropRPGSubObjects"
    }
	/*/
	enum comboRespawnMonsters
	{
		// "translateRespawnMonstersOff",  // 0
		"translateRespawnMonstersFew",     // 0 // na Enemy tyle co graczy
		"translateRespawnMonstersAverage", // 1 // + 1 
		"translateRespawnMonstersMany",    // 2 // + 2
	multi:
		"translateRespawnMonsters"
	}
	/**/
	/*
	enum comboQuestsDifficulty
	{
		"translateQuestsDifficultyEasy",   // 0
		"translateQuestsDifficultyMedium", // 1
		"translateQuestsDifficultyHard",   // 2
	multi:
		"translateQuestsDifficulty"
	}
	/**/
	
	state Initialize;
	state Working;
	state MissionComplete;

	#ifdef RPGX_START_CUTSCENE
	state StartCutscene;
	#endif
	
	#ifdef RPGX_SAFE_AREA
	function int RPGX_IsSafePoint(int x, int y, int z);
	#endif RPGX_SAFE_AREA

#define LOAD(MarkerName, MarkerNum, FileName, FileNum) \
	if ( PointExist(MarkerName, MarkerNum) ) \
	{ \
		SetStringBuff(0, FileName "_%d.txt", FileNum); \
		m_pNeutral.LoadObjectsFromFile(GetPointX(MarkerName, MarkerNum), GetPointY(MarkerName, MarkerNum), GetPointZ(MarkerName, MarkerNum), GetPointAlpha(MarkerName, MarkerNum)/64, GetStringBuff(0)); \
		TRACEF("("); \
		TRACEF(GetPointX(MarkerName, MarkerNum)); \
		TRACEF(","); \
		TRACEF(GetPointY(MarkerName, MarkerNum)); \
		TRACEF(","); \
		TRACEF(GetPointZ(MarkerName, MarkerNum)); \
		TRACEF(") LoadedObjectsFromFile "); \
		TRACEF(GetStringBuff(0)); \
		TRACEF("\n"); \
	}

#define LOAD_GIVER(QuestNum, FileName, FileNum) \
	SetStringBuff(0, FileName "_%d.txt", FileNum); \
	m_pNeutral.LoadObjectsFromFile(m_anQuestGiverX[QuestNum], m_anQuestGiverY[QuestNum], m_anQuestGiverZ[QuestNum], m_anQuestGiverA[QuestNum]/64, GetStringBuff(0)); \
	TRACEF("("); \
	TRACEF(m_anQuestGiverX[QuestNum]); \
	TRACEF(","); \
	TRACEF(m_anQuestGiverY[QuestNum]); \
	TRACEF(","); \
	TRACEF(m_anQuestGiverZ[QuestNum]); \
	TRACEF(") LoadedObjectsFromFile "); \
	TRACEF(GetStringBuff(0)); \
	TRACEF("\n");

#define LOAD_QUEST(QuestNum, FileName, FileNum) \
	SetStringBuff(0, FileName "_%d.txt", FileNum); \
	m_pNeutral.LoadObjectsFromFile(m_anQuestX[QuestNum], m_anQuestY[QuestNum], m_anQuestZ[QuestNum], m_anQuestA[QuestNum]/64, GetStringBuff(0)); \
	TRACEF("("); \
	TRACEF(m_anQuestX[QuestNum]); \
	TRACEF(","); \
	TRACEF(m_anQuestY[QuestNum]); \
	TRACEF(","); \
	TRACEF(m_anQuestZ[QuestNum]); \
	TRACEF(") LoadedObjectsFromFile "); \
	TRACEF(GetStringBuff(0)); \
	TRACEF("\n");

	function int RPG_IsEasy()
	{
		if ( comboRespawnMonsters == 0 )
		{
			return true;
		}
		
		return false;
	}
	
	function int RPG_IsMedium()
	{
		if ( comboRespawnMonsters == 1 )
		{
			return true;
		}
		
		return false;
	}
	
	function int RPG_IsHard()
	{
		if ( comboRespawnMonsters == 2 )
		{
			return true;
		}
		
		return false;
	}

	function void CreateBonusItem(unitex uHero, int x, int y, int z)
	{
		int nExp;
		int nRandMax;
		int nHeroType;
		int i, n;

		if ( uHero )
		{
			nHeroType = 1 << (uHero.GetRPGCharacterType()-1);
			nExp = uHero.GetExperienceLevel();
		}
		else
		{
			n = m_auHero.GetSize();
			for (i=0; i<n; ++i)
			{
				uHero = m_auHero[i];

				if (uHero != null)
				{
					nHeroType = nHeroType | (1 << (uHero.GetRPGCharacterType()-1));
					if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
				}
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		if ( nExp > 18 && RAND(50) == 7 ) // ;) 1/50 unique (chyba, ze juz ktos ma to o polowe mniejsze 1/100)
		{
			CreateUniqueItem(nHeroType, nExp, x, y, z);
		}
		else
		{
			CreateBonusItem(nHeroType, nExp, x, y, z);
		}
	}

	function void OnQuestDoneExpAdd(unitex uHero)
	{
		int nExp;
		int nExpToAdd;

		nExp = uHero.GetExperienceLevel();

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		if ( RPG_IsEasy() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =  20;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =  30;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =  50;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd = 100;
			else if ( nExp >= 19               ) nExpToAdd = 200;
			else __ASSERT_FALSE();
		}
		else if ( RPG_IsMedium() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =  10;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =  15;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =  30;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd =  50;
			else if ( nExp >= 19               ) nExpToAdd = 100;
			else __ASSERT_FALSE();
		}
		else if ( RPG_IsHard() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =   5;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =   7;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =  15;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd =  30;
			else if ( nExp >= 19               ) nExpToAdd =  50;
			else __ASSERT_FALSE();
		}
		else __ASSERT_FALSE();

		uHero.SetExperiencePoints(uHero.GetExperiencePoints() + nExpToAdd);
	}

	function void OnBonusDoneExpAdd(unitex uHero)
	{
		int nExp;
		int nExpToAdd;

		nExp = uHero.GetExperienceLevel();

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		if ( RPG_IsEasy() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =  10;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =  15;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =  20;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd =  30;
			else if ( nExp >= 19               ) nExpToAdd =  50;
			else __ASSERT_FALSE();
		}
		else if ( RPG_IsMedium() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =   5;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =   7;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =  10;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd =  15;
			else if ( nExp >= 19               ) nExpToAdd =  25;
			else __ASSERT_FALSE();
		}
		else if ( RPG_IsHard() )
		{
			     if ( nExp >=  0 && nExp <=  3 ) nExpToAdd =   1;
			else if ( nExp >=  4 && nExp <=  8 ) nExpToAdd =   3;
			else if ( nExp >=  9 && nExp <= 13 ) nExpToAdd =   5;
			else if ( nExp >= 14 && nExp <= 18 ) nExpToAdd =   8;
			else if ( nExp >= 19               ) nExpToAdd =  12;
			else __ASSERT_FALSE();
		}
		else __ASSERT_FALSE();

		uHero.SetExperiencePoints(uHero.GetExperiencePoints() + nExpToAdd);
	}

	function void SetRespawnHere(unitex uHero)
	{
		int nIFFNum;

        if (uHero != null)
        {
		    nIFFNum = uHero.GetIFFNumber();

		    m_anPlayerRespawnX[nIFFNum] = uHero.GetLocationX();
		    m_anPlayerRespawnY[nIFFNum] = uHero.GetLocationY();
		    m_anPlayerRespawnZ[nIFFNum] = uHero.GetLocationZ();
        }
	}
	function void ClearRespawn(unitex uHero)
	{
		int nIFFNum;

        if (uHero != null)
        {
		    nIFFNum = uHero.GetIFFNumber();

		    m_anPlayerRespawnX[nIFFNum] = -1;
		    m_anPlayerRespawnY[nIFFNum] = -1;
		    m_anPlayerRespawnZ[nIFFNum] = -1;
        }
	}
	function int IsRespawnSafe(int nIFFNum)
	{
		if ( m_anPlayerRespawnX[nIFFNum] == -1 )
		{
			return false;
		}

		if ( IsUnitNearPoint(m_anPlayerRespawnX[nIFFNum], m_anPlayerRespawnY[nIFFNum], m_anPlayerRespawnZ[nIFFNum], rangeSafeRespawn, m_pEnemy.GetIFF()) )
		{
			return false;
		}

		return true;
	}

	function void CreateGold(unitex uHero, int x, int y, int z)
	{
		int nExp;
		int i, n;

		if ( uHero )
		{
			nExp = uHero.GetExperienceLevel();
		}
		else
		{
			n = m_auHero.GetSize();
			for (i=0; i<n; ++i)
			{
				uHero = m_auHero[i];

				if (uHero != null)
				{
					if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
				}
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		CreateGold(nExp, x, y, z);
	}

#define IGNORE_NOTIFY_ATTACK(UnitName) rPlayer.IgnoreNotifyAttackUnit(UnitName, true);

	function void UpdateEnemies()
	{
		int n, i;
		int m, j;
		int x, y, z;
		unitex uHero, uEnemy;
		platoon pEnemy;
		player rPlayer;

		int nLevel;
		
		int nExp, nTmp, nUnits, nTmp2;
		int nHeroX, nHeroY, nHeroZ;
		int nIFFNum;
		
		int bCreate;

		m = m_auHero.GetSize();
		for (j=0; j<m; ++j)
		{
			uHero = m_auHero[j];

			nExp = uHero.GetExperienceLevel();

#ifdef RPG_DEMO
			if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif
			
			rPlayer = GetPlayer(uHero.GetIFFNumber());

			if ( nExp > rPlayer.GetScriptData(dataHeroExp) )
			{
				rPlayer.SetScriptData(dataHeroExp, nExp);

				if ( nExp >=  2 && nExp <=  2 ) { nLevel =  1; }
				if ( nExp >=  3 && nExp <=  4 ) { nLevel =  2; }
				if ( nExp >=  5 && nExp <=  8 ) { nLevel =  3; }
				if ( nExp >=  9 && nExp <= 13 ) { nLevel =  4; }
				if ( nExp >= 14 && nExp <= 19 ) { nLevel =  5; }
				if ( nExp >= 20 && nExp <= 26 ) { nLevel =  6; }
				if ( nExp >= 27 && nExp <= 34 ) { nLevel =  7; }
				if ( nExp >= 35 && nExp <= 43 ) { nLevel =  8; }
				if ( nExp >= 44               ) { nLevel =  9; }

				if ( nLevel > 0 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_WOLF")
				}
				if ( nLevel > 1 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_WOLF"     )
					IGNORE_NOTIFY_ATTACK("RPG_BROWNWOLF")
				}
				if ( nLevel > 2 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_WOLF"     )
					IGNORE_NOTIFY_ATTACK("RPG_BROWNWOLF")
					IGNORE_NOTIFY_ATTACK("RPG_WHITEWOLF")
				}
				if ( nLevel > 3 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_MAGICWOLF"       )
					IGNORE_NOTIFY_ATTACK("RPG_BLACKBEAR"       )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON1"       )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON1M"      )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTER" )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTERM")
					IGNORE_NOTIFY_ATTACK("RPG_OLDWITCH"        )
					IGNORE_NOTIFY_ATTACK("RPG_OLDWITCH2"       )
				}
				if ( nLevel > 4 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_HELLWOLF1"         )
					IGNORE_NOTIFY_ATTACK("RPG_BEAR"              )
					IGNORE_NOTIFY_ATTACK("RPG_GIANT3"            )
					
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT"            )
					IGNORE_NOTIFY_ATTACK("RPG_BANDITT"           )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_HUNTER"     )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_FOOTMAN"    )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_SPEARMAN"   )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON2"         )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON2M"        )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTER2"  )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTER2M" )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMAN" )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMANM")
					IGNORE_NOTIFY_ATTACK("RPG_OLDWITCH2"         )
					IGNORE_NOTIFY_ATTACK("RPG_OLDWITCH3"         )

					IGNORE_NOTIFY_ATTACK("RPG_SKELETONT1"        )
				}
				if ( nLevel > 5 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_HELLWOLF2"          )
					IGNORE_NOTIFY_ATTACK("RPG_WHITEBEAR"          )
					IGNORE_NOTIFY_ATTACK("RPG_GIANT2"             )
					IGNORE_NOTIFY_ATTACK("RPG_RINGLEADER"         )
					IGNORE_NOTIFY_ATTACK("RPG_BANDITM"            )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_HUNTER2"     )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_FOOTMAN2"    )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_SPEARMAN2"   )
					IGNORE_NOTIFY_ATTACK("RPG_MONSTER"            )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON3"          )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON3M"         )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTER3"   )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_HUNTER3M"  )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMAN2" )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMAN2M")
					IGNORE_NOTIFY_ATTACK("RPG_DARKPRIEST"         )
					IGNORE_NOTIFY_ATTACK("RPG_DARKSORCERER"       )

					IGNORE_NOTIFY_ATTACK("RPG_SKELETONT2"         )
					IGNORE_NOTIFY_ATTACK("RPG_KNIGHTGHOST"        )
				}
				if ( nLevel > 6 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_HELLWOLF3"          )
					IGNORE_NOTIFY_ATTACK("RPG_GIANT"              )
					IGNORE_NOTIFY_ATTACK("RPG_MONSTER2"           )
					IGNORE_NOTIFY_ATTACK("RPG_WEREWOLF"           )
					IGNORE_NOTIFY_ATTACK("RPG_RINGLEADERM"        )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_HUNTER3"     )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_FOOTMAN3"    )
					IGNORE_NOTIFY_ATTACK("RPG_BANDIT_SPEARMAN3"   )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON4"          )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON4M"         )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMAN3" )
					IGNORE_NOTIFY_ATTACK("RPG_SKELETON_SPEARMAN3M")
					IGNORE_NOTIFY_ATTACK("RPG_AMAZONE"            )
					IGNORE_NOTIFY_ATTACK("RPG_DARKPRIEST2"        )
					IGNORE_NOTIFY_ATTACK("RPG_DARKSORCERER2"      )

					IGNORE_NOTIFY_ATTACK("RPG_SKELETONT3"         )
					IGNORE_NOTIFY_ATTACK("RPG_KNIGHTGHOST2"       )
				}
				if ( nLevel > 7 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_HELLWOLF4"    )
					IGNORE_NOTIFY_ATTACK("RPG_GIANTSPECIAL" )
					IGNORE_NOTIFY_ATTACK("RPG_MONSTER3"     )
					IGNORE_NOTIFY_ATTACK("RPG_WEREWOLF2"    )
					IGNORE_NOTIFY_ATTACK("RPG_MINOTAUR"     )
					IGNORE_NOTIFY_ATTACK("RPG_IGOR"         )
					IGNORE_NOTIFY_ATTACK("RPG_AMAZONE2"     )
					IGNORE_NOTIFY_ATTACK("RPG_DARKPRIEST3"  )
					IGNORE_NOTIFY_ATTACK("RPG_DARKSORCERER3")
					
					IGNORE_NOTIFY_ATTACK("RPG_SKELETONT4"   )
					IGNORE_NOTIFY_ATTACK("RPG_MINOTAURT"    )
					IGNORE_NOTIFY_ATTACK("RPG_MAGICBEAR"    )
					IGNORE_NOTIFY_ATTACK("RPG_KNIGHTGHOST3" )
				}
				if ( nLevel > 8 )
				{
					IGNORE_NOTIFY_ATTACK("RPG_MONSTER4"    )
					IGNORE_NOTIFY_ATTACK("RPG_IGOR2"       )
					IGNORE_NOTIFY_ATTACK("RPG_MINOTAUR2"   )
					IGNORE_NOTIFY_ATTACK("RPG_AMAZONE3"    )
					IGNORE_NOTIFY_ATTACK("RPG_NECROMANCER" )

					IGNORE_NOTIFY_ATTACK("RPG_MINOTAURT2"  )
					IGNORE_NOTIFY_ATTACK("RPG_KNIGHTGHOST4")
				}
			}
		}

		// if ( !comboRespawnMonsters ) return;
		
		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			
			nHeroX = uHero.GetLocationX();
			nHeroY = uHero.GetLocationY();
			nHeroZ = uHero.GetLocationZ();

			nIFFNum = uHero.GetIFFNumber();

			if ( !m_abNoEnemy[nIFFNum] && !IsUnitNearPoint(nHeroX, nHeroY, nHeroZ, m_nNoEnemyTrigerRange, m_pEnemy.GetIFF()) )
			{
				m_anNoEnemyX[nIFFNum] = nHeroX;
				m_anNoEnemyY[nIFFNum] = nHeroY;
				m_anNoEnemyZ[nIFFNum] = nHeroZ;
				
				// TRACE4("NoEnemy added:", m_anNoEnemyX[nIFFNum], m_anNoEnemyY[nIFFNum], m_anNoEnemyZ[nIFFNum]);
				
				m_abNoEnemy[nIFFNum] = true;
			}
			else if ( m_abNoEnemy[nIFFNum] )
			{
				if ( Distance(nHeroX, nHeroY, m_anNoEnemyX[nIFFNum], m_anNoEnemyY[nIFFNum]) > m_nNoEnemyTrigerRange || nHeroZ != m_anNoEnemyZ[nIFFNum] )
				{
					if ( !IsUnitNearPoint(m_anNoEnemyX[nIFFNum], m_anNoEnemyY[nIFFNum], m_anNoEnemyZ[nIFFNum], m_nNoEnemyTrigerRange, m_pEnemy.GetIFF()) )
					{
						m_anKilledX.Add( m_anNoEnemyX[nIFFNum] );
						m_anKilledY.Add( m_anNoEnemyY[nIFFNum] );
						m_anKilledZ.Add( m_anNoEnemyZ[nIFFNum] );
						
						// TRACE4("NoEnemy->Killed:", m_anNoEnemyX[nIFFNum], m_anNoEnemyY[nIFFNum], m_anNoEnemyZ[nIFFNum]);
					}
					else
					{
						// TRACE4("NoEnemy removed:", m_anNoEnemyX[nIFFNum], m_anNoEnemyY[nIFFNum], m_anNoEnemyZ[nIFFNum]);
					}
					
					m_abNoEnemy[nIFFNum] = false;
				}
			}
		}

		ASSERT( m_anKilledX.GetSize() == m_anKilledY.GetSize() );
		ASSERT( m_anKilledX.GetSize() == m_anKilledZ.GetSize() );
		
		n = m_anKilledX.GetSize();
		
		if ( n > 0 )
		{
			i = RAND(n);
			
			x = m_anKilledX[i];
			y = m_anKilledY[i];
			z = m_anKilledZ[i];
			
			bCreate = true;
			
			/*
			m = m_anSafeArea.GetSize();
			for (j=0; j<m; ++j)
			{
				if ( IsPointNearMarker(x, y, z, m_anSafeArea[j], rangeSafe) )
				{
					// TRACE4("Killed removed:", x, y, z);
					
					m_anKilledX.RemoveAt(i);
					m_anKilledY.RemoveAt(i);
					m_anKilledZ.RemoveAt(i);
					
					bCreate = false;
					break;
				}
			}
			*/
			if ( bCreate ) if ( IsUnitNearPoint(x, y, z, rangeSafe, m_pNeutral1.GetIFF()|m_pNeutral2.GetIFF()) )
			{
				// TRACE4("Killed removed:", x, y, z);
					
				m_anKilledX.RemoveAt(i);
				m_anKilledY.RemoveAt(i);
				m_anKilledZ.RemoveAt(i);
				
				bCreate = false;
			}

			#ifdef RPGX_SAFE_AREA
				if ( bCreate ) if ( RPGX_IsSafePoint(x, y, z) )
				{
					// TRACE4("Killed removed:", x, y, z);
						
					m_anKilledX.RemoveAt(i);
					m_anKilledY.RemoveAt(i);
					m_anKilledZ.RemoveAt(i);
					
					bCreate = false;
				}
			#endif RPGX_SAFE_AREA

			m = m_auHero.GetSize();
			if ( bCreate ) for (j=0; j<m; ++j)
			{
				uHero = m_auHero[j];
				
				if ( uHero.GetLocationZ() == z && Distance(x, y, uHero.GetLocationX(), uHero.GetLocationY()) < rangeSee )
				{
					bCreate = false;
					break;
				}

				rPlayer = GetPlayer(uHero.GetIFFNumber());
				
				if ( Distance(x, y, rPlayer.GetStartingPointX(), rPlayer.GetStartingPointY()) < rangeSafe )
				{
					m_anKilledX.RemoveAt(i);
					m_anKilledY.RemoveAt(i);
					m_anKilledZ.RemoveAt(i);

					bCreate = false;
					break;
				}

				if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
			}

#ifdef RPG_DEMO
			if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

			if ( bCreate )
			{
				pEnemy = CreateMonster(m_pEnemy, nExp, x, y, z, m_nAddToMonstersLevel);

				if ( (pEnemy != null) && pEnemy.GetUnitsCount() > 0 )
				{
					TRACE4("Enemy created:", x, y, z);

					m_anKilledX.RemoveAt(i);
					m_anKilledY.RemoveAt(i);
					m_anKilledZ.RemoveAt(i);
				}
				else __ASSERT_FALSE();
			}
		}
	}

	function void InitializeShop(unitex uShop, int nItems)
	{
		int nExp;
		unitex uHero;
		int nRandMax;
		int nHeroType;
		int anItems[];
		int i, n;

		int nHeroTypeItems;
		int nShopTypeItems;

		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];

			if (uHero != null)
			{
				nHeroType = nHeroType | (1 << (uHero.GetRPGCharacterType()-1));
				if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		anItems.Create(0);

		if ( uShop.GetShopType() == 255 )
		{
			nHeroTypeItems = nItems;
			nShopTypeItems = 0;
		}
		else if ( nHeroType == 0 )
		{
			nHeroTypeItems = 0;
			nShopTypeItems = nItems;
		}
		else
		{
			nHeroTypeItems = (nItems*1) / 4;
			nShopTypeItems = (nItems*3) / 4;

			if ( RAND(4) < ((nItems*1)%4) ) ++nHeroTypeItems;
			if ( RAND(4) < ((nItems*3)%4) ) ++nShopTypeItems;
		}

		nRandMax = AddShopItems(uShop, nHeroType, nExp, false, anItems, false, false);
		if ( nRandMax > 0 ) for (i=0; i<nHeroTypeItems; ++i)
		{
			anItems.Add(RAND(nRandMax));
		}

		AddShopItems(uShop, nHeroType, nExp, false, anItems, true, true);

		anItems.RemoveAll();

		nRandMax = AddShopItems(uShop, nHeroType, nExp, true, anItems, false, false);
		if ( nRandMax > 0 ) for (i=0; i<nShopTypeItems; ++i)
		{
			anItems.Add(RAND(nRandMax));
		}

		AddShopItems(uShop, nHeroType, nExp, true, anItems, true, true);

		KeepShopItems(uShop, nHeroType, nExp);
	}

	function void UpdateShop(unitex uShop)
	{
		uShop.RemovePlayerInventoryFromShop();

		if ( RAND(7) == 0 || uShop.CountInventoryObjectsInShop() < 7 )
		{
			uShop.RemoveAllInventoryFromShop();
			InitializeShop(uShop, 8);
		}
		else
		{
			InitializeShop(uShop, 1);
		}
	}

	/************************************************************************/
	
	function void OpenGate(int nGate)
	{
		unitex uGate;

		uGate = m_auGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateOpened);
	}
	function void CloseGate(int nGate)
	{
		unitex uGate;

		uGate = m_auGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateClosed);
	}

	function void OpenQuestGate(int nGate)
	{
		unitex uGate;

		uGate = m_auQuestGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateOpened);
	}
	function void CloseQuestGate(int nGate)
	{
		unitex uGate;

		uGate = m_auQuestGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateClosed);
	}

	function void OpenQuestDoneGate(int nGate)
	{
		unitex uGate;

		uGate = m_auQuestDoneGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateOpened);
	}
	function void CloseQuestDoneGate(int nGate)
	{
		unitex uGate;

		uGate = m_auQuestDoneGate[nGate];
		if ( uGate ) uGate.CommandBuildingSetGateMode(modeGateClosed);
	}

	function unitex CreateUnitAtQuestGiver(player pPlayer, int nQuestGiver, string strName)
	{
		int x, y, z, a;

		ASSERT( pPlayer != null );

		x = m_anQuestGiverX[nQuestGiver];
		y = m_anQuestGiverY[nQuestGiver];
		z = m_anQuestGiverZ[nQuestGiver];
		a = m_anQuestGiverA[nQuestGiver];

		if ( a == 0 )
		{
			y = y - 1;
		}
		else if ( a == 64 )
		{
			x = x + 1;
		}
		else if ( a == 128 )
		{
			y = y + 1;
		}
		else if ( a == 192 )
		{
			x = x - 1;
		}
		else __ASSERT_FALSE();

		return pPlayer.CreateUnit(x, y, z, a, strName);
	}
	function unitex CreateUnitAtQuestSupport(player pPlayer, int nQuestSupport, string strName)
	{
		int x, y, z, a;

		ASSERT( pPlayer != null );

		x = m_anQuestGiverX[nQuestSupport];
		y = m_anQuestGiverY[nQuestSupport];
		z = m_anQuestGiverZ[nQuestSupport];
		a = m_anQuestGiverA[nQuestSupport];

		if ( a == 0 )
		{
			x = x + 1;
			y = y - 1;
		}
		else if ( a == 64 )
		{
			x = x + 1;
			y = y + 1;
		}
		else if ( a == 128 )
		{
			x = x - 1;
			y = y + 1;
		}
		else if ( a == 192 )
		{
			x = x - 1;
			y = y - 1;
		}
		else __ASSERT_FALSE();

		return pPlayer.CreateUnit(x, y, z, a, strName);
	}
	function unitex CreateObjectAtQuestSupport(int nQuestSupport, string strName)
	{
		int x, y, z, a;

		x = m_anQuestGiverX[nQuestSupport];
		y = m_anQuestGiverY[nQuestSupport];
		z = m_anQuestGiverZ[nQuestSupport];
		a = m_anQuestGiverA[nQuestSupport];

		if ( a == 0 )
		{
			x = x + 1;
			y = y - 1;
		}
		else if ( a == 64 )
		{
			x = x + 1;
			y = y + 1;
		}
		else if ( a == 128 )
		{
			x = x - 1;
			y = y + 1;
		}
		else if ( a == 192 )
		{
			x = x - 1;
			y = y - 1;
		}
		else __ASSERT_FALSE();

		return CreateObject(x, y, z, a, strName);
	}
	function unitex CreateUnitAtQuest(player pPlayer, int nQuest, string strName)
	{
		ASSERT( pPlayer != null );

		return pPlayer.CreateUnit(m_anQuestX[nQuest], m_anQuestY[nQuest], m_anQuestZ[nQuest], m_anQuestA[nQuest], strName);
	}
	function unitex CreateUnitAtQuestGuard(player pPlayer, int nQuestGuard, string strName)
	{
		ASSERT( pPlayer != null );

		return pPlayer.CreateUnit(m_anQuestGuardX[nQuestGuard], m_anQuestGuardY[nQuestGuard], m_anQuestGuardZ[nQuestGuard], m_anQuestGuardA[nQuestGuard], strName);
	}

	function platoon CreateUnitsAtQuest(platoon platUnits, player pPlayer, int nQuest, string strName, int nUnits)
	{
		int i;
		unitex uTmp;

		ASSERT( pPlayer != null );
		ASSERT( platUnits != null );

		for ( i=0; i<nUnits; ++i )
		{
			uTmp = CreateUnitAtQuest(pPlayer, nQuest, strName);

			ASSERT( uTmp != null );

			platUnits.AddUnitToPlatoon(uTmp.GetUnitRef());
		}

		return platUnits;
	}
	function platoon CreateUnitsAtQuestGuard(platoon platUnits, player pPlayer, int nQuestGuard, string strName, int nUnits)
	{
		int i;
		unitex uTmp;

		ASSERT( pPlayer != null );
		ASSERT( platUnits != null );

		for ( i=0; i<nUnits; ++i )
		{
			uTmp = CreateUnitAtQuestGuard(pPlayer, nQuestGuard, strName);

			ASSERT( uTmp != null );

			platUnits.AddUnitToPlatoon(uTmp.GetUnitRef());
		}

		return platUnits;
	}

	function platoon CreateUnitsAtQuest(player pPlayer, int nQuest, string strName, int nUnits)
	{
		platoon platTmp;

		ASSERT( pPlayer != null );

		platTmp = pPlayer.CreatePlatoon();
		platTmp.EnableFeatures(disposeIfNoUnits,true);

		return CreateUnitsAtQuest(platTmp, pPlayer, nQuest, strName, nUnits);
	}
	function platoon CreateUnitsAtQuestGuard(player pPlayer, int nQuestGuard, string strName, int nUnits)
	{
		platoon platTmp;

		ASSERT( pPlayer != null );

		platTmp = pPlayer.CreatePlatoon();
		platTmp.EnableFeatures(disposeIfNoUnits,true);

		return CreateUnitsAtQuestGuard(platTmp, pPlayer, nQuestGuard, strName, nUnits);
	}

	function int IsPointNearMarker(int x, int y, int z, int nMarker, int nRange)
	{
		ASSERT( PointExist(nMarker) );
		
		if ( z == GetPointZ(nMarker) && Distance(x, y, GetPointX(nMarker), GetPointY(nMarker)) <= nRange )
		{
			return true;
		}
		
		return false;
	}
	function int IsUnitNearUnitIgnoreZ(unitex uUnitA, unitex uUnitB, int nRange)
	{
		ASSERT( uUnitA != null );
		ASSERT( uUnitB != null );
		ASSERT( uUnitA.IsLive() );
		
		if ( Distance ( uUnitA.GetLocationX(), uUnitA.GetLocationY(), uUnitB.GetLocationX(), uUnitB.GetLocationY() ) <= nRange )
		{
			return true;
		}
		
		return false;
	}
	function int IsFreeArea3x3AtMarker(int nMarker)
	{
		int x, y, z;
		
		z = GetPointZ(nMarker);
		
		for ( x=GetPointX(nMarker)-1; x<=GetPointX(nMarker)+1; ++x )
		{
			for ( y=GetPointY(nMarker)-1; y<=GetPointY(nMarker)+1; ++y )
			{
				if ( GetUnit(x, y, z) != null ) return false;
			}
		}
		
		return true;
	}
	function int GetHeroes()
	{
		return m_auHero.GetSize();
	}
	function int GetHeroesExp()
	{
		int nExp, i, n;
		unitex uHero;
		
		nExp = 0;
		
		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			nExp = nExp + uHero.GetExperienceLevel();
		}
		
		if ( n != 0 ) nExp = nExp/n;
		
		// if ( comboQuestsDifficulty == 0 ) nExp = nExp - 2; // easy
		// else if ( comboQuestsDifficulty == 2 ) nExp = nExp + 1; // hard
		
		if ( nExp < 0 ) nExp = 0;
		
#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		return nExp;
	}
	function int GetHeroesMaxExp()
	{
		int nExp, i, n;
		unitex uHero;
		
		nExp = 0;
		
		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			if ( nExp < uHero.GetExperienceLevel() ) nExp = uHero.GetExperienceLevel();
		}
		
#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		return nExp;
	}

	function int CountHeroesInventory(string strArtName)
	{
		int nCount, i, n;
		unitex uHero;
		
		nCount = 0;
		
		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			nCount = nCount + uHero.CountInventory(strArtName);
		}
		
		return nCount;
	}

	function unitex GetPlayerHero(int nIFFNum)
	{
		int i, n;
		unitex uHero;
		
		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			if ( uHero.GetIFFNumber() == nIFFNum ) return uHero;
		}
		
		return null;
	}

	function void ShowAreaAtMarker(unitex uHero, int nMarker, int nRange)
	{
		ASSERT( uHero != null );
		ASSERT( PointExist(nMarker) );

		ShowArea(uHero.GetIFF(), GetPointX(nMarker), GetPointY(nMarker), GetPointZ(nMarker), nRange, showAreaPassives|showAreaBuildings|showAreaUnits);
	}
	function unitex CreateUnitAtSartingPoint(player pPlayer, string strName)
	{
		ASSERT( pPlayer != null );
		
		return pPlayer.CreateUnit(pPlayer.GetStartingPointX(), pPlayer.GetStartingPointY(), 0, 0, strName);
	}
	function int AddWorldMapSignAtUnit(unitex uHero, unitex uUnit, int nType, int nTime)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		ASSERT( uUnit != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.AddWorldMapSign(uUnit.GetLocationX(), uUnit.GetLocationY(), uUnit.GetLocationZ(), nType, nTime);
		
		return true;
	}
	function int AddWorldMapSignAtMarker(unitex uHero, int nMarker, int nType, int nTime)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		ASSERT( PointExist(nMarker) );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.AddWorldMapSign(GetPointX(nMarker), GetPointY(nMarker), GetPointZ(nMarker), nType, nTime);
		
		return true;
	}
	function int AddWorldMapSignAtMarker(player pPlayer, int nMarker, int nType, int nTime)
	{
		ASSERT( pPlayer != null );
		ASSERT( PointExist(nMarker) );
		
		pPlayer.AddWorldMapSign(GetPointX(nMarker), GetPointY(nMarker), GetPointZ(nMarker), nType, nTime);
		
		return true;
	}
	function int AddWorldMapSignAtQuestGiver(unitex uHero, int nQuestGiver, int nType, int nTime)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.AddWorldMapSign(m_anQuestGiverX[nQuestGiver], m_anQuestGiverY[nQuestGiver], m_anQuestGiverZ[nQuestGiver], nType, nTime);
		
		return true;
	}
	function int AddWorldMapSignAtQuest(unitex uHero, int nQuest, int nType, int nTime)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.AddWorldMapSign(m_anQuestX[nQuest], m_anQuestY[nQuest], m_anQuestZ[nQuest], nType, nTime);
		
		return true;
	}
	function int RemoveWorldMapSignAtUnit(unitex uHero, unitex uUnit)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		ASSERT( uUnit != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.RemoveWorldMapSign(uUnit.GetLocationX(), uUnit.GetLocationY(), uUnit.GetLocationZ());
		
		return true;
	}
	function int RemoveWorldMapSignAtMarker(unitex uHero, int nMarker)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		ASSERT( PointExist(nMarker) );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.RemoveWorldMapSign(GetPointX(nMarker), GetPointY(nMarker), GetPointZ(nMarker));
		
		return true;
	}
	function int RemoveWorldMapSignAtQuestGiver(unitex uHero, int nQuestGiver)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.RemoveWorldMapSign(m_anQuestGiverX[nQuestGiver], m_anQuestGiverY[nQuestGiver], m_anQuestGiverZ[nQuestGiver]);
		
		return true;
	}
	function int RemoveWorldMapSignAtQuest(unitex uHero, int nQuest)
	{
		player pPlayer;
		
		ASSERT( uHero != null );
		
		pPlayer = GetPlayer(uHero.GetIFFNumber());
		pPlayer.RemoveWorldMapSign(m_anQuestX[nQuest], m_anQuestY[nQuest], m_anQuestZ[nQuest]);
		
		return true;
	}
	#ifndef RPG_X_EC
		function int UpdateReadyQuestMarker(unitex uHero, int nQuest)
		{
			player pPlayer;
			int nLastQuest;
			
			ASSERT( uHero != null );
			
			pPlayer = GetPlayer(uHero.GetIFFNumber());
			nLastQuest = pPlayer.GetScriptData(dataQuestMarker);
			
			if ( nQuest == nLastQuest ) return true;
			
			if ( nLastQuest >= 0 )
			{
				RemoveWorldMapSignAtQuestGiver(uHero, nLastQuest);
			}
			
			if ( nQuest >= 0 )
			{
				AddWorldMapSignAtQuestGiver(uHero, nQuest, 2, -1);
			}
			
			pPlayer.SetScriptData(dataQuestMarker, nQuest);
			
			return true;
		}
	#endif
	
	/*
	function void InitializePlayers()
	{
		int i, j;
		player p1, p2;
		
		INITIALIZE_PLAYER( Neutral1 );
		INITIALIZE_PLAYER( Neutral2 );
		INITIALIZE_PLAYER( Enemy    );
		INITIALIZE_PLAYER( Animals  );
		
		m_pNeutral1.EnableAI(false);
		m_pNeutral2.EnableAI(false);
		m_pEnemy.EnableAI(false);
		
		SetNeutrals(m_pNeutral1, m_pNeutral2);
		SetNeutrals(m_pNeutral1, m_pEnemy);
		SetNeutrals(m_pNeutral1, m_pAnimals);
		SetNeutrals(m_pNeutral2, m_pEnemy);
		SetNeutrals(m_pNeutral2, m_pAnimals);
		SetNeutrals(m_pEnemy, m_pAnimals);
		
		// m_pNeutral1.SetEnemy(m_pAnimals);
		// m_pNeutral2.SetEnemy(m_pAnimals);
		
		m_pNeutral1.EnableAIFeatures(aiBNSendResult,false);
		m_pNeutral2.EnableAIFeatures(aiBNSendResult,false);
		m_pEnemy.EnableAIFeatures(aiBNSendResult,false);
		m_pAnimals.EnableAIFeatures(aiBNSendResult,false);
		
		for ( i=0; i<constMaxPlayers; ++i )
		{
			p1 = GetPlayer(i);
			
			if ( p1 != null )
			{
				p1.EnableAIFeatures(aiBNSendResult,false);
				p1.SetMaxMoney(100);
				p1.SetMoney(0);
				
				p1.SetMaxCountLimitForObject("COW",0);
				p1.SetMaxCountLimitForObject("WOODCUTTER",0);
				p1.SetMaxCountLimitForObject("FOOTMAN",0);
				p1.SetMaxCountLimitForObject("HUNTER",0);
				p1.SetMaxCountLimitForObject("SPEARMAN",0);
				p1.SetMaxCountLimitForObject("SHEPHERD",0);
				p1.SetMaxCountLimitForObject("PRIEST",0);
				p1.SetMaxCountLimitForObject("WITCH",0);
				p1.SetMaxCountLimitForObject("BARRACKS",0);
				p1.SetMaxCountLimitForObject("COURT",0);
				p1.SetMaxCountLimitForObject("TEMPLE",0);
				p1.SetMaxCountLimitForObject("SHRINE",0);
				p1.SetMaxCountLimitForObject("PRIESTESS",0);
				p1.SetMaxCountLimitForObject("KNIGHT",0);
				p1.SetMaxCountLimitForObject("SORCERER",0);
				p1.SetMaxCountLimitForObject("DIPLOMAT",0);
				
				SetNeutrals(p1, m_pNeutral1);
				SetNeutrals(p1, m_pNeutral2);
				SetEnemies(p1, m_pEnemy);
				SetEnemies(p1, m_pAnimals);
				
				for ( j=i+1; j<constMaxPlayers; ++j )
				{
					p2 = GetPlayer(j);
					
					if ( p2 != null )
					{
						SetNeutrals(p1, p2);
					}
				}
			}
		}
	}
	/**/
	function void StartTalk(int iQuest)
	{
		unitex uTalker, uTalkerSmoke;
		
		// ASSERT( iQuest >= constFirstQuest && iQuest <= constLastQuest );
		
		uTalker = m_auTalker[iQuest];
		uTalkerSmoke = CreateObjectAtUnit(uTalker, "PART_TALK");
		
		ASSERT( uTalker != null && uTalker.IsLive() );
		ASSERT( uTalkerSmoke != null );
		
		uTalkerSmoke.SetSmokeObject(uTalker.GetUnitRef(), true, true, true, true);
		
		m_auTalkerSmoke[iQuest] = uTalkerSmoke;
	}
	function void StopTalk(int iQuest)
	{
		unitex uTalker, uTalkerSmoke;
		
		// ASSERT( iQuest >= constFirstQuest && iQuest <= constLastQuest );
		
		uTalker = m_auTalker[iQuest];
		uTalkerSmoke = m_auTalkerSmoke[iQuest];
		
		ASSERT( uTalker != null && uTalker.IsLive() );
		ASSERT( uTalkerSmoke != null );
		
		uTalkerSmoke.RemoveUnit();
		
		m_auTalkerSmoke[iQuest] = null;
	}
	function void AddTalkGiver(player pPlayer, int iQuest, int nTalk)
	{
		int nVar;
		int nGiver, bMale;
		unitex uHero, uTalker;
		int nIFFNum;
		
		nGiver = m_anQuestGiver[iQuest];
		uTalker = m_auTalker[iQuest];
		uHero = m_auQuestHero[iQuest];
		nIFFNum = uHero.GetIFFNumber();
		
		if ( uHero.GetRPGCharacterType() == 5 || uHero.GetRPGCharacterType() == 7 )
		{
			bMale = false;
		}
		else
		{
			bMale = true;
		}
		
		     if ( nGiver <  2 ) SetStringBuff(0, "Sorcerer"  );
		else if ( nGiver <  5 ) SetStringBuff(0, "Priest"    );
		else if ( nGiver <  9 ) SetStringBuff(0, "Knight"    );
		else if ( nGiver < 12 ) SetStringBuff(0, "Footman"   );
		else if ( nGiver < 13 ) SetStringBuff(0, "Hunter"    );
		else if ( nGiver < 15 ) SetStringBuff(0, "Diplomat"  );
		else if ( nGiver < 17 ) SetStringBuff(0, "Priestessa");
		else if ( nGiver < 20 ) SetStringBuff(0, "Shepherd"  );
		else if ( nGiver < 22 ) SetStringBuff(0, "Woodcutter");
		else if ( nGiver < 23 ) SetStringBuff(0, "Witch"     );
		else if ( nGiver < 24 ) SetStringBuff(0, "Spearman"  );
		else if ( nGiver < 27 ) SetStringBuff(0, "Sorcerer"  );
		else if ( nGiver < 29 ) SetStringBuff(0, "Priest"    );
		else if ( nGiver < 30 ) SetStringBuff(0, "Knight"    );
		else if ( nGiver < 32 ) SetStringBuff(0, "Footman"   );
		else if ( nGiver < 36 ) SetStringBuff(0, "Hunter"    );
		else if ( nGiver < 38 ) SetStringBuff(0, "Shepherd"  );
		else if ( nGiver < 42 ) SetStringBuff(0, "Witch"     );
		else if ( nGiver < 45 ) SetStringBuff(0, "Diplomat"  );
		else if ( nGiver < 48 ) SetStringBuff(0, "Priestessa");
		else if ( nGiver < 51 ) SetStringBuff(0, "Woodcutter");
		else if ( nGiver < 55 ) SetStringBuff(0, "Spearman"  );
		else __ASSERT_FALSE();
		
		if ( nTalk == 0 ) SetStringBuff(1, "Order_Conversation");
		else if ( nTalk == 4 ) SetStringBuff(1, "Order_Luck");
		else if ( nTalk == 7 ) SetStringBuff(1, "OrderDone_Award");
		else if ( nTalk == 9 ) SetStringBuff(1, "OrderDone_Luck2");
		else __ASSERT_FALSE();
		
		if ( bMale ) SetStringBuff(2, "Male"); else SetStringBuff(2, "Female");
		
		nVar = RAND(6)+1;
		
		SetStringBuff(3, "translate_%s_%s_%s_0%d"                                               , GetStringBuff(0), GetStringBuff(1), GetStringBuff(2), nVar);
		SetStringBuff(4, "Dialogs\\Quests\\Quest givers\\%s\\%s_%s_%s_0%d.wav", GetStringBuff(0), GetStringBuff(0), GetStringBuff(1), GetStringBuff(2), nVar);
		
		pPlayer.AddTalk(uTalker, 0, true, false, GetStringBuff(4), 20, GetStringBuff(3));
		pPlayer.AddTalkSyncPrev(uHero, 1, true, false);
	}
	function void AddTalkHero(player pPlayer, int iQuest, int nTalk)
	{
		int nVar;
		int nGiver, bMale;
		unitex uHero, uTalker;
		int nIFFNum;
		
		nGiver = m_anQuestGiver[iQuest];
		uTalker = m_auTalker[iQuest];
		uHero = m_auQuestHero[iQuest];
		nIFFNum = uHero.GetIFFNumber();
		
		     if ( uHero.GetRPGCharacterType() == 1 ) SetStringBuff(0, "Hunter"    );
		else if ( uHero.GetRPGCharacterType() == 2 ) SetStringBuff(0, "Footman"   );
		else if ( uHero.GetRPGCharacterType() == 3 ) SetStringBuff(0, "Woodcutter");
		else if ( uHero.GetRPGCharacterType() == 4 ) SetStringBuff(0, "Spearman"  );
		else if ( uHero.GetRPGCharacterType() == 5 ) SetStringBuff(0, "Priestessa");
		else if ( uHero.GetRPGCharacterType() == 6 ) SetStringBuff(0, "Sorcerer"  );
		else if ( uHero.GetRPGCharacterType() == 7 ) SetStringBuff(0, "Amazon"    );
		else __ASSERT_FALSE();
		
		     if ( nGiver <  2 ) bMale = true;
		else if ( nGiver <  5 ) bMale = true;
		else if ( nGiver <  9 ) bMale = true;
		else if ( nGiver < 12 ) bMale = true;
		else if ( nGiver < 13 ) bMale = true;
		else if ( nGiver < 15 ) bMale = false;
		else if ( nGiver < 17 ) bMale = false;
		else if ( nGiver < 20 ) bMale = true;
		else if ( nGiver < 22 ) bMale = true;
		else if ( nGiver < 23 ) bMale = false;
		else if ( nGiver < 24 ) bMale = true;
		else if ( nGiver < 27 ) bMale = true;
		else if ( nGiver < 29 ) bMale = true;
		else if ( nGiver < 30 ) bMale = true;
		else if ( nGiver < 32 ) bMale = true;
		else if ( nGiver < 36 ) bMale = true;
		else if ( nGiver < 38 ) bMale = true;
		else if ( nGiver < 42 ) bMale = false;
		else if ( nGiver < 45 ) bMale = false;
		else if ( nGiver < 48 ) bMale = false;
		else if ( nGiver < 51 ) bMale = true;
		else if ( nGiver < 55 ) bMale = true;
		else __ASSERT_FALSE();
		
		     if ( nTalk == 1 ) SetStringBuff(1, "Order_Answer");
		else if ( nTalk == 3 ) SetStringBuff(1, "Order_Pickup");
		else if ( nTalk == 6 ) SetStringBuff(1, "OrderDone_ItWasEasy");
		else if ( nTalk == 8 ) SetStringBuff(1, "OrderDone_Thanks");
		else __ASSERT_FALSE();
		
		if ( bMale ) SetStringBuff(2, "Male"); else SetStringBuff(2, "Female");
		
		if ( !bMale && ( nTalk == 1 || nTalk == 8 ) ) nVar = RAND(4)+1; else nVar = RAND(6)+1;
		
		SetStringBuff(3, "translate_%s_%s_%s_0%d"                                         , GetStringBuff(0), GetStringBuff(1), GetStringBuff(2), nVar);
		SetStringBuff(4, "Dialogs\\Quests\\Heroes\\%s\\%s_%s_%s_0%d.wav", GetStringBuff(0), GetStringBuff(0), GetStringBuff(1), GetStringBuff(2), nVar);
		
		pPlayer.AddTalk(uHero, 0, true, false, GetStringBuff(4), 20, GetStringBuff(3));
		pPlayer.AddTalkSyncPrev(uTalker, 1, true, false);
	}
	function void PlayStartDialog(int iQuest)
	{
		player pPlayer;
		unitex uTalker, uHero;
		int nGiver, nIFFNum;
		
		uTalker = m_auTalker[iQuest];
		nGiver = m_anQuestGiver[iQuest];
		
		uHero = m_auQuestHero[iQuest];
		nIFFNum = uHero.GetIFFNumber();
		
		pPlayer = GetPlayer(nIFFNum);
		pPlayer.PrepareInterfaceToTalk(true, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_COLOR);
		
		uTalker.CommandSetTalkMode(true, true, false);
		uHero.CommandSetTalkMode(true, true, true);
		
		pPlayer.SetScriptData(dataMovementMode, uHero.SetCustomEvent(1, 0, 0, 0, 0, null));
		uHero.CommandSetMovementMode(modeHoldPos);
		uTalker.CommandSetMovementMode(modeHoldPos);
		
		uTalker.CommandTurn(uTalker.GetAngleToTarget(uHero.GetUnitRef()));
		uHero.CommandTurn(uHero.GetAngleToTarget(uTalker.GetUnitRef()));
		
		PlayerLookAtUnit       (pPlayer, uTalker, constLookAtHeight, -1, constLookAtView);
		PlayerDelayedLookAtUnit(pPlayer, uTalker, constLookAtHeight, -1, constLookAtView, 20, true); // bo czasem kamera gdzies uciekala

		pPlayer.StartTalkDefinition();
		
		AddTalkGiver(pPlayer, iQuest, 0);
		AddTalkHero (pPlayer, iQuest, 1);
		     if ( nGiver ==  0 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Bring_Begin.wav"        , 20, "translate_Sorcerer_Quest_Bring_Begin"      );
		else if ( nGiver ==  1 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill_Begin.wav"         , 20, "translate_Sorcerer_Quest_Kill_Begin"       );
		else if ( nGiver ==  2 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Bring_Begin.wav"            , 20, "translate_Priest_Quest_Bring_Begin"        );
		else if ( nGiver ==  3 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Escort_Begin.wav"           , 20, "translate_Priest_Quest_Escort_Begin"       );
		else if ( nGiver ==  4 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Specjal_Begin.wav"          , 20, "translate_Priest_Quest_Specjal_Begin"      );
		else if ( nGiver ==  5 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring_Begin.wav"            , 20, "translate_Knight_Quest_Bring_Begin"        );
		else if ( nGiver ==  6 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring2_Begin.wav"           , 20, "translate_Knight_Quest_Bring2_Begin"       );
		else if ( nGiver ==  7 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring3_Begin.wav"           , 20, "translate_Knight_Quest_Bring3_Begin"       );
		else if ( nGiver ==  8 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Kill_Begin.wav"             , 20, "translate_Knight_Quest_Kill_Begin"         );
		else if ( nGiver ==  9 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Bring_Begin.wav"          , 20, "translate_Footman_Quest_Bring_Begin"       );
		else if ( nGiver == 10 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Escort_Begin.wav"         , 20, "translate_Footman_Quest_Escort_Begin"      );
		else if ( nGiver == 11 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Deliver_Begin.wav"        , 20, "translate_Footman_Quest_Deliver_Begin"     );
		else if ( nGiver == 12 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Bring_Begin.wav"            , 20, "translate_Hunter_Quest_Bring_Begin"        );
		else if ( nGiver == 13 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Bring_Begin.wav"        , 20, "translate_Diplomat_Quest_Bring_Begin"      );
		else if ( nGiver == 14 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Escort_Begin.wav"       , 20, "translate_Diplomat_Quest_Escort_Begin"     );
		else if ( nGiver == 15 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Bring_Begin.wav"    , 20, "translate_Priestessa_Quest_Bring_Begin"    );
		else if ( nGiver == 16 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Kill_Begin.wav"     , 20, "translate_Priestessa_Quest_Kill_Begin"     );
		else if ( nGiver == 17 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Bring_Begin.wav"        , 20, "translate_Shepherd_Quest_Bring_Begin"      );
		else if ( nGiver == 18 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Kill_Begin.wav"         , 20, "translate_Shepherd_Quest_Kill_Begin"       );
		else if ( nGiver == 19 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Lead_Begin.wav"         , 20, "translate_Shepherd_Quest_Lead_Begin"       );
		else if ( nGiver == 20 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Kill_Begin.wav"     , 20, "translate_Woodcutter_Quest_Kill_Begin"     );
		else if ( nGiver == 21 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Special_Begin.wav"  , 20, "translate_Woodcutter_Quest_Special_Begin"  );
		else if ( nGiver == 22 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Kill_Begin.wav"               , 20, "translate_Witch_Quest_Kill_Begin"          );
		else if ( nGiver == 23 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Bring_Begin.wav"        , 20, "translate_Spearman_Quest_Bring_Begin"      );
		else if ( nGiver == 24 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill2_Begin.wav"        , 20, "translate_Sorcerer_Quest_Kill2_Begin"      );
		else if ( nGiver == 25 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill3_Begin.wav"        , 20, "translate_Sorcerer_Quest_Kill3_Begin"      );
		else if ( nGiver == 26 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Prisoner_Begin.wav"     , 20, "translate_Sorcerer_Quest_Prisoner_Begin"   );
		else if ( nGiver == 27 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Deliver_Begin.wav"          , 20, "translate_Priest_Quest_Deliver_Begin"      );
		else if ( nGiver == 28 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Kill_Begin.wav"             , 20, "translate_Priest_Quest_Kill_Begin"         );
		else if ( nGiver == 29 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_KillTake_Begin.wav"         , 20, "translate_Knight_Quest_KillTake_Begin"     );
		else if ( nGiver == 30 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Kill_Begin.wav"           , 20, "translate_Footman_Quest_Kill_Begin"        );
		else if ( nGiver == 31 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_KillTake_Begin.wav"       , 20, "translate_Footman_Quest_KillTake_Begin"    );
		else if ( nGiver == 32 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner_Begin.wav"         , 20, "translate_Hunter_Quest_Prisoner_Begin"     );
		else if ( nGiver == 33 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner2_Begin.wav"        , 20, "translate_Hunter_Quest_Prisoner2_Begin"    );
		else if ( nGiver == 34 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner3_Begin.wav"        , 20, "translate_Hunter_Quest_Prisoner3_Begin"    );
		else if ( nGiver == 35 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Bring2_Begin.wav"           , 20, "translate_Hunter_Quest_Bring2_Begin"       );
		else if ( nGiver == 36 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Kill2_Begin.wav"        , 20, "translate_Shepherd_Quest_Kill2_Begin"      );
		else if ( nGiver == 37 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Escort_Begin.wav"       , 20, "translate_Shepherd_Quest_Escort_Begin"     );
		else if ( nGiver == 38 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Prisoner_Begin.wav"           , 20, "translate_Witch_Quest_Prisoner_Begin"      );
		else if ( nGiver == 39 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Bring_Begin.wav"              , 20, "translate_Witch_Quest_Bring_Begin"         );
		else if ( nGiver == 40 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Kill2_Begin.wav"              , 20, "translate_Witch_Quest_Kill2_Begin"         );
		else if ( nGiver == 41 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Escort_Begin.wav"             , 20, "translate_Witch_Quest_Escort_Begin"        );
		else if ( nGiver == 42 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Escort2_Begin.wav"      , 20, "translate_Diplomat_Quest_Escort2_Begin"    );
		else if ( nGiver == 43 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Prisoner_Begin.wav"     , 20, "translate_Diplomat_Quest_Prisoner_Begin"   );
		else if ( nGiver == 44 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_KillTake_Begin.wav"     , 20, "translate_Diplomat_Quest_KillTake_Begin"   );
		else if ( nGiver == 45 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Escort_Begin.wav"   , 20, "translate_Priestessa_Quest_Escort_Begin"   );
		else if ( nGiver == 46 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Deliver_Begin.wav"  , 20, "translate_Priestessa_Quest_Deliver_Begin"  );
		else if ( nGiver == 47 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Prisoner_Begin.wav" , 20, "translate_Priestessa_Quest_Prisoner_Begin" );
		else if ( nGiver == 48 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_KillTake_Begin.wav" , 20, "translate_Woodcutter_Quest_KillTake_Begin" );
		else if ( nGiver == 49 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_KillTake2_Begin.wav", 20, "translate_Woodcutter_Quest_KillTake2_Begin");
		else if ( nGiver == 50 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Bring_Begin.wav"    , 20, "translate_Woodcutter_Quest_Bring_Begin"    );
		else if ( nGiver == 51 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Kill_Begin.wav"         , 20, "translate_Spearman_Quest_Kill_Begin"       );
		else if ( nGiver == 52 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Prisoner_Begin.wav"     , 20, "translate_Spearman_Quest_Prisoner_Begin"   );
		else if ( nGiver == 53 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Escort_Begin.wav"       , 20, "translate_Spearman_Quest_Escort_Begin"     );
		else if ( nGiver == 54 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Deliver_Begin.wav"      , 20, "translate_Spearman_Quest_Deliver_Begin"    );
		else __ASSERT_FALSE();
		pPlayer.AddTalkSyncPrev(uHero, 1, true, false);
		AddTalkHero (pPlayer, iQuest, 3);
		if ( m_anQuestType[iQuest] != questEscort && m_anQuestType[iQuest] != questDeliver && m_anQuestType[iQuest] != questKillTake ) // BUGFIX 1718
		{
			AddTalkGiver(pPlayer, iQuest, 4);
		}
		
		m_anPlayerQuest[nIFFNum] = iQuest;
	}
	function void PlayEndDialog(int iQuest)
	{
		player pPlayer;
		unitex uTalker, uHero;
		int nGiver, nIFFNum;
		
		uTalker = m_auTalker[iQuest];
		nGiver = m_anQuestGiver[iQuest];
		
		uHero = m_auQuestHero[iQuest];
		nIFFNum = uHero.GetIFFNumber();
		
		pPlayer = GetPlayer(nIFFNum);
		
		uTalker.CommandTurn(uTalker.GetAngleToTarget(uHero.GetUnitRef()));
		uHero.CommandTurn(uHero.GetAngleToTarget(uTalker.GetUnitRef()));
		
		uTalker.CommandSetTalkMode(true, true, false);
		uHero.CommandSetTalkMode(true, true, true);
		
		pPlayer.SetScriptData(dataMovementMode, uHero.SetCustomEvent(1, 0, 0, 0, 0, null));
		uHero.CommandSetMovementMode(modeHoldPos);
		uTalker.CommandSetMovementMode(modeHoldPos);
		
		pPlayer.PrepareInterfaceToTalk(true, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_COLOR);
		
		PlayerLookAtUnit       (pPlayer, uTalker, constLookAtHeight, -1, constLookAtView);
		PlayerDelayedLookAtUnit(pPlayer, uTalker, constLookAtHeight, -1, constLookAtView, 20, true); // bo czasem kamera gdzies uciekala
		
		pPlayer.StartTalkDefinition();
		
		     if ( nGiver ==  0 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Bring_End.wav"        , 20, "translate_Sorcerer_Quest_Bring_End"      );
		else if ( nGiver ==  1 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill_End.wav"         , 20, "translate_Sorcerer_Quest_Kill_End"       );
		else if ( nGiver ==  2 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Bring_End.wav"            , 20, "translate_Priest_Quest_Bring_End"        );
		else if ( nGiver ==  3 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Escort_End.wav"           , 20, "translate_Priest_Quest_Escort_End"       );
		else if ( nGiver ==  4 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Specjal_End.wav"          , 20, "translate_Priest_Quest_Specjal_End"      );
		else if ( nGiver ==  5 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring_End.wav"            , 20, "translate_Knight_Quest_Bring_End"        );
		else if ( nGiver ==  6 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring2_End.wav"           , 20, "translate_Knight_Quest_Bring2_End"       );
		else if ( nGiver ==  7 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Bring3_End.wav"           , 20, "translate_Knight_Quest_Bring3_End"       );
		else if ( nGiver ==  8 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_Kill_End.wav"             , 20, "translate_Knight_Quest_Kill_End"         );
		else if ( nGiver ==  9 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Bring_End.wav"          , 20, "translate_Footman_Quest_Bring_End"       );
		else if ( nGiver == 10 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Escort_End.wav"         , 20, "translate_Footman_Quest_Escort_End"      );
		else if ( nGiver == 11 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Deliver_End.wav"        , 20, "translate_Footman_Quest_Deliver_End"     );
		else if ( nGiver == 12 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Bring_End.wav"            , 20, "translate_Hunter_Quest_Bring_End"        );
		else if ( nGiver == 13 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Bring_End.wav"        , 20, "translate_Diplomat_Quest_Bring_End"      );
		else if ( nGiver == 14 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Escort_End.wav"       , 20, "translate_Diplomat_Quest_Escort_End"     );
		else if ( nGiver == 15 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Bring_End.wav"    , 20, "translate_Priestessa_Quest_Bring_End"    );
		else if ( nGiver == 16 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Kill_End.wav"     , 20, "translate_Priestessa_Quest_Kill_End"     );
		else if ( nGiver == 17 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Bring_End.wav"        , 20, "translate_Shepherd_Quest_Bring_End"      );
		else if ( nGiver == 18 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Kill_End.wav"         , 20, "translate_Shepherd_Quest_Kill_End"       );
		else if ( nGiver == 19 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Lead_End.wav"         , 20, "translate_Shepherd_Quest_Lead_End"       );
		else if ( nGiver == 20 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Kill_End.wav"     , 20, "translate_Woodcutter_Quest_Kill_End"     );
		else if ( nGiver == 21 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Special_End.wav"  , 20, "translate_Woodcutter_Quest_Special_End"  );
		else if ( nGiver == 22 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Kill_End.wav"               , 20, "translate_Witch_Quest_Kill_End"          );
		else if ( nGiver == 23 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Bring_End.wav"        , 20, "translate_Spearman_Quest_Bring_End"      );
		else if ( nGiver == 24 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill2_End.wav"        , 20, "translate_Sorcerer_Quest_Kill2_End"      );
		else if ( nGiver == 25 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Kill3_End.wav"        , 20, "translate_Sorcerer_Quest_Kill3_End"      );
		else if ( nGiver == 26 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Sorcerer\\Sorcerer_Quest_Prisoner_End.wav"     , 20, "translate_Sorcerer_Quest_Prisoner_End"   );
		else if ( nGiver == 27 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Deliver_End.wav"          , 20, "translate_Priest_Quest_Deliver_End"      );
		else if ( nGiver == 28 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priest\\Priest_Quest_Kill_End.wav"             , 20, "translate_Priest_Quest_Kill_End"         );
		else if ( nGiver == 29 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Knight\\Knight_Quest_KillTake_End.wav"         , 20, "translate_Knight_Quest_KillTake_End"     );
		else if ( nGiver == 30 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_Kill_End.wav"           , 20, "translate_Footman_Quest_Kill_End"        );
		else if ( nGiver == 31 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Footman\\Footman_Quest_KillTake_End.wav"       , 20, "translate_Footman_Quest_KillTake_End"    );
		else if ( nGiver == 32 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner_End.wav"         , 20, "translate_Hunter_Quest_Prisoner_End"     );
		else if ( nGiver == 33 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner2_End.wav"        , 20, "translate_Hunter_Quest_Prisoner2_End"    );
		else if ( nGiver == 34 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Prisoner3_End.wav"        , 20, "translate_Hunter_Quest_Prisoner3_End"    );
		else if ( nGiver == 35 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Hunter\\Hunter_Quest_Bring2_End.wav"           , 20, "translate_Hunter_Quest_Bring2_End"       );
		else if ( nGiver == 36 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Kill2_End.wav"        , 20, "translate_Shepherd_Quest_Kill2_End"      );
		else if ( nGiver == 37 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Shepherd\\Shepherd_Quest_Escort_End.wav"       , 20, "translate_Shepherd_Quest_Escort_End"     );
		else if ( nGiver == 38 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Prisoner_End.wav"           , 20, "translate_Witch_Quest_Prisoner_End"      );
		else if ( nGiver == 39 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Bring_End.wav"              , 20, "translate_Witch_Quest_Bring_End"         );
		else if ( nGiver == 40 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Kill2_End.wav"              , 20, "translate_Witch_Quest_Kill2_End"         );
		else if ( nGiver == 41 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Witch\\Witch_Quest_Escort_End.wav"             , 20, "translate_Witch_Quest_Escort_End"        );
		else if ( nGiver == 42 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Escort2_End.wav"      , 20, "translate_Diplomat_Quest_Escort2_End"    );
		else if ( nGiver == 43 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_Prisoner_End.wav"     , 20, "translate_Diplomat_Quest_Prisoner_End"   );
		else if ( nGiver == 44 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Diplomat\\Diplomat_Quest_KillTake_End.wav"     , 20, "translate_Diplomat_Quest_KillTake_End"   );
		else if ( nGiver == 45 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Escort_End.wav"   , 20, "translate_Priestessa_Quest_Escort_End"   );
		else if ( nGiver == 46 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Deliver_End.wav"  , 20, "translate_Priestessa_Quest_Deliver_End"  );
		else if ( nGiver == 47 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Priestessa\\Priestessa_Quest_Prisoner_End.wav" , 20, "translate_Priestessa_Quest_Prisoner_End" );
		else if ( nGiver == 48 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_KillTake_End.wav" , 20, "translate_Woodcutter_Quest_KillTake_End" );
		else if ( nGiver == 49 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_KillTake2_End.wav", 20, "translate_Woodcutter_Quest_KillTake2_End");
		else if ( nGiver == 50 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Woodcutter\\Woodcutter_Quest_Bring_End.wav"    , 20, "translate_Woodcutter_Quest_Bring_End"    );
		else if ( nGiver == 51 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Kill_End.wav"         , 20, "translate_Spearman_Quest_Kill_End"       );
		else if ( nGiver == 52 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Prisoner_End.wav"     , 20, "translate_Spearman_Quest_Prisoner_End"   );
		else if ( nGiver == 53 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Escort_End.wav"       , 20, "translate_Spearman_Quest_Escort_End"     );
		else if ( nGiver == 54 ) pPlayer.AddTalk(uTalker, 1, true, false, "Dialogs\\Quests\\Quest givers\\Spearman\\Spearman_Quest_Deliver_End.wav"      , 20, "translate_Spearman_Quest_Deliver_End"    );
		else __ASSERT_FALSE();
		pPlayer.AddTalkSyncPrev(uHero, 1, true, false);
		AddTalkHero (pPlayer, iQuest, 6);
		AddTalkGiver(pPlayer, iQuest, 7);
		AddTalkHero (pPlayer, iQuest, 8);
		AddTalkGiver(pPlayer, iQuest, 9);
		
		m_anPlayerQuest[nIFFNum] = iQuest;
	}
	function void RegisterGoalEx(int iQuest, string strName)
	{
		// int i;
		// player pPlayer;
		// 
		// for ( i=0; i<constMaxPlayers; ++i )
		// 	{
		// 	pPlayer = GetPlayer(i);
		// 	if ( pPlayer != null ) pPlayer.RegisterGoal(iQuest, strName);
		// 	}
		SetStringBuff(bufferGoals+iQuest, strName);
	}
	function int IsGoalEnabledEx(int iQuest)
	{
		if ( m_anExGoalToGoalMap[iQuest] > 0 ) return true;
		
		return false;
	}
	function void EnableGoalEx(player pPlayer, int iQuest, int bEnable)
	{
		int nGoal;
		int nIFFNum;
		
		nGoal = m_anExGoalToGoalMap[iQuest];
		if ( nGoal < 1 )
		{
			nIFFNum = pPlayer.GetIFFNumber();
			m_anPlayerLastGoal[nIFFNum] = m_anPlayerLastGoal[nIFFNum] + 1;
			m_anExGoalToGoalMap[iQuest] = nGoal = m_anPlayerLastGoal[nIFFNum];
			// if ( nGoal > constMaxGoals ) pPlayer.EnableGoal(constFirstGoal+nGoal-constMaxGoals, false);
			
			pPlayer.RegisterGoal(constFirstGoal+nGoal, GetStringBuff(bufferGoals+iQuest));
		}
		
		pPlayer.EnableGoal(constFirstGoal+nGoal, bEnable);
	}
	function void SetGoalStateEx(player pPlayer, int iQuest, int nState)
	{
		int nGoal;
		
		if ( !IsGoalEnabledEx(iQuest) ) EnableGoalEx(pPlayer, iQuest, false);
		
		nGoal = m_anExGoalToGoalMap[iQuest];
		pPlayer.SetGoalState(constFirstGoal+nGoal, nState); // FAKE: zakladam, ze pPlayer jest poprawny (jesli nie jest "zaznaczy" mu sie inny goal)
	}
	#ifndef RPG_X_EC
		function void UpdateFindQuestGoal()
		{
			int i;
			player pPlayer;
			
			for ( i=0; i<constMaxPlayers; ++i )
			{
				pPlayer = GetPlayer(i);
				if ( pPlayer != null )
				{
					if ( m_anQuestReady.GetSize() > 0 )
					{
						pPlayer.RegisterGoal(goalFindQuest, "translateGoalFindQuestRPG", m_anQuestReady.GetSize());
					}
					else
					{
						pPlayer.EnableGoal(goalFindQuest, false);
					}
				}
			}
		}
	#endif

	function void CreatePrize(int iQuest)
	{
		unitex uHero;
		int x, y, z;

		uHero = m_auQuestHero[iQuest];
		
		z = uHero.GetLocationZ();		
		x = uHero.GetLocationX();
		y = uHero.GetLocationY();
		
		/*
		for ( x=uHero.GetLocationX()-1; x<=uHero.GetLocationX()+1; ++x )
		{
			for ( y=uHero.GetLocationY()-1; y<=uHero.GetLocationY()+1; ++y )
			{
				if ( GetUnit(x, y, z) == null )
				{
					break;
				}
			}
			if ( GetUnit(x, y, z) == null )
			{
				break;
			}
		}
		*/

		CreateQuestPrize(uHero, x, y, z);
	}
	function int CreateGiver(int iQuest)
	{
		unitex uTmp;
		int nGiver;

		int nCounter;
		int nExp;
		
		nGiver = RAND(constQuests);

		nCounter = constQuests;
		while ( m_abGiverUsed[nGiver] && nCounter > 0 )
		{
			nGiver = (nGiver+1)%constQuests;
			--nCounter;
		}

		if ( nCounter == 0 ) // nie ma juz wolnych
		{
			return -1;

			/*
			nExp = GetHeroesMaxExp();

			nCounter = constQuests;
			while ( (m_anQuestMapCount[nGiver] == 0 || m_anQuestGiverMapCount[nGiver] == 0 || GetMinLevel(nGiver) > nExp || GetMaxLevel(nGiver) < nExp ) && nCounter > 0 )
			{
				nGiver = (nGiver+1)%constQuests;
				--nCounter;
			}
			/**/
		}

		ASSERT( nCounter > 0 );

		m_abGiverUsed[nGiver] = true;
		
		LOAD_GIVER(iQuest, "RPG_QUEST_GIVER", GetQuestGiverMap(nGiver))

		     if ( nGiver <  2 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SORCERER"  );
		else if ( nGiver <  5 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_PRIEST"    );
		else if ( nGiver <  9 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_KNIGHT"    );
		else if ( nGiver < 12 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_FOOTMAN"   );
		else if ( nGiver < 13 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_HUNTER"    );
		else if ( nGiver < 15 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "DIPLOMAT"      );
		else if ( nGiver < 17 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_PRIESTESS" );
		else if ( nGiver < 20 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SHEPHERD"  );
		else if ( nGiver < 22 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_WOODCUTTER");
		else if ( nGiver < 23 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_OLDWITCH"  );
		else if ( nGiver < 24 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SPEARMAN"  );
		else if ( nGiver < 27 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SORCERER"  );
		else if ( nGiver < 29 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_PRIEST"    );
		else if ( nGiver < 30 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_KNIGHT"    );
		else if ( nGiver < 32 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_FOOTMAN"   );
		else if ( nGiver < 36 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_HUNTER"    );
		else if ( nGiver < 38 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SHEPHERD"  );
		else if ( nGiver < 42 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_OLDWITCH"  );
		else if ( nGiver < 45 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "DIPLOMAT"      );
		else if ( nGiver < 48 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_PRIESTESS" );
		else if ( nGiver < 51 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_WOODCUTTER");
		else if ( nGiver < 55 ) uTmp = CreateUnitAtQuestGiver(m_pNeutral1, iQuest, "NPC_SPEARMAN"  );
		else __ASSERT_FALSE();
		
		ASSERT( uTmp != null );
		
		uTmp.SetScriptImmortal(true);
		uTmp.EnableCapture(false);
		uTmp.EnableConversionByMagic(false);

		uTmp.SetIsQuestGiverUnit(true);
		
		m_auTalker[iQuest] = uTmp;
		m_anQuestGiver[iQuest] = nGiver;
		
		m_auTalkerSmoke[iQuest] = null;
		
		return nGiver;
	}
	function void CreateBringQuest(int iQuest, string strArt)
	{
		m_anQuestType[iQuest] = questBring;
		
		SetStringBuff(bufferBringArts+iQuest, strArt);
	}
	function void CreateKillQuest(int iQuest)
	{
		m_anQuestType[iQuest] = questKill;
	}
	function void CreateEscortQuest(int iQuest)
	{
		m_anQuestType[iQuest] = questEscort;
		
		m_auEscort[iQuest] = m_auTalker[iQuest];
		m_auEscortTo[iQuest] = CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "INVISIBLE_OBJECT");
		
		m_auSpecial[iQuest] = m_auEscort[iQuest];
	}
	function void CreateEscortFromQuest(int iQuest, string strName)
	{
		unitex uTmp;
		m_anQuestType[iQuest] = questEscortFrom;
		
		m_auEscort[iQuest] = CreateUnitAtQuest(m_pNeutral2, iQuest, strName);
		m_auEscortTo[iQuest] = CreateObjectAtQuestSupport(iQuest, "INVISIBLE_OBJECT");
		
		m_auSpecial[iQuest] = m_auTalker[iQuest];
		
		uTmp = m_auEscort[iQuest];
		uTmp.SetScriptImmortal(true);
		uTmp.EnableCapture(false);
		uTmp.EnableConversionByMagic(false);
	}
	function void CreateEscortQuest(int iQuest, string strName, string strNameTo)
	{
		unitex uTmp;
		m_anQuestType[iQuest] = questEscort;
		
		m_auEscort[iQuest] = CreateUnitAtQuestSupport(m_pNeutral2, iQuest, strName);
		m_auEscortTo[iQuest] = CreateUnitAtQuest(m_pNeutral1, iQuest, strNameTo);
		
		uTmp = m_auEscort[iQuest];
		uTmp.SetScriptImmortal(true);
		uTmp.EnableCapture(false);
		uTmp.EnableConversionByMagic(false);
		
		uTmp = m_auEscortTo[iQuest];
		uTmp.SetScriptImmortal(true);
		uTmp.EnableCapture(false);
		uTmp.EnableConversionByMagic(false);
		
		uTmp.SetIsQuestGiverUnit(true); // BUGFIX #206
		
		m_auSpecial[iQuest] = m_auEscortTo[iQuest];
	}
	function void CreateDeliverQuest(int iQuest, string strArt, string strNameTo)
	{
		unitex uTmp;
		m_anQuestType[iQuest] = questDeliver;
		
		SetStringBuff(bufferBringArts+iQuest, strArt);

		m_auEscortTo[iQuest] = CreateUnitAtQuest(m_pNeutral1, iQuest, strNameTo);
		
		uTmp = m_auEscortTo[iQuest];
		uTmp.SetScriptImmortal(true);
		uTmp.EnableCapture(false);
		uTmp.EnableConversionByMagic(false);
		
		uTmp.SetIsQuestGiverUnit(true); // BUGFIX #206
		
		m_auSpecial[iQuest] = m_auEscortTo[iQuest];
	}
	function void CreateKillTakeQuest(int iQuest)
	{
		m_anQuestType[iQuest] = questKillTake;
	}
	function void CreateKillBringQuest(int iQuest, string strArt)
	{
		m_anQuestType[iQuest] = questKillBring;
		
		SetStringBuff(bufferBringArts+iQuest, strArt);
	}
	function void CreateQuest(int iQuest, int nGiver)
	{
		int nRandNum;
		platoon platTmp;
		int dx, dy;

		// ASSERT( iQuest >= constFirstQuest && iQuest <= constLastQuest );

		if ( nGiver == -1 )
		{
			CloseQuestDoneGate(iQuest);

			return;
		}

		LOAD_QUEST(iQuest, "RPG_QUEST", GetQuestMap(nGiver))

		m_auQuestGate[iQuest] = GetLoadedGate(m_pNeutral);

		     if ( nGiver ==  0 ) { CreateBringQuest(iQuest, "RPG_Sorcerer_Bring");                        RegisterGoalEx(iQuest, "translate_Sorcerer_Quest_Bring_Goal");      }
		else if ( nGiver ==  1 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Sorcerer_Quest_Kill_Goal");       }
		else if ( nGiver ==  2 ) { CreateBringQuest(iQuest, "RPG_Priest_Bring");                          RegisterGoalEx(iQuest, "translate_Priest_Quest_Bring_Goal");        }
		else if ( nGiver ==  3 ) { CreateEscortQuest(iQuest/*, "GADGET32"*/);                             RegisterGoalEx(iQuest, "translate_Priest_Quest_Escort_Goal");       }
		else if ( nGiver ==  4 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Priest_Quest_Specjal_Goal");      }
		else if ( nGiver ==  5 ) { CreateBringQuest(iQuest, "RPG_Knight_Bring");                          RegisterGoalEx(iQuest, "translate_Knight_Quest_Bring_Goal");        }
		else if ( nGiver ==  6 ) { CreateBringQuest(iQuest, "RPG_Knight_Bring2");                         RegisterGoalEx(iQuest, "translate_Knight_Quest_Bring2_Goal");       }
		else if ( nGiver ==  7 ) { CreateBringQuest(iQuest, "RPG_Knight_Bring3");                         RegisterGoalEx(iQuest, "translate_Knight_Quest_Bring3_Goal");       }
		else if ( nGiver ==  8 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Knight_Quest_Kill_Goal");         }
		else if ( nGiver ==  9 ) { CreateBringQuest(iQuest, "RPG_Footman_Bring");                         RegisterGoalEx(iQuest, "translate_Footman_Quest_Bring_Goal");       }
		else if ( nGiver == 10 ) { CreateEscortQuest(iQuest, "NPC_PRIESTESS", "NPC_FOOTMAN");             RegisterGoalEx(iQuest, "translate_Footman_Quest_Escort_Goal");      }
		else if ( nGiver == 11 ) { CreateDeliverQuest(iQuest, "RPG_Footman_Deliver", "NPC_FOOTMAN");      RegisterGoalEx(iQuest, "translate_Footman_Quest_Deliver_Goal");     }
		else if ( nGiver == 12 ) { CreateBringQuest(iQuest, "RPG_Hunter_Bring");                          RegisterGoalEx(iQuest, "translate_Hunter_Quest_Bring_Goal");        }
		else if ( nGiver == 13 ) { CreateBringQuest(iQuest, "RPG_Diplomat_Bring");                        RegisterGoalEx(iQuest, "translate_Diplomat_Quest_Bring_Goal");      }
		else if ( nGiver == 14 ) { CreateEscortQuest(iQuest, "NPC_SHEPHERD", "DIPLOMAT");                 RegisterGoalEx(iQuest, "translate_Diplomat_Quest_Escort_Goal");     }
		else if ( nGiver == 15 ) { CreateBringQuest(iQuest, "RPG_Priestessa_Bring");                      RegisterGoalEx(iQuest, "translate_Priestessa_Quest_Bring_Goal");    }
		else if ( nGiver == 16 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Priestessa_Quest_Kill_Goal");     }
		else if ( nGiver == 17 ) { CreateBringQuest(iQuest, "RPG_Shepherd_Bring");                        RegisterGoalEx(iQuest, "translate_Shepherd_Quest_Bring_Goal");      }
		else if ( nGiver == 18 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Shepherd_Quest_Kill_Goal");       }
		else if ( nGiver == 19 ) { CreateEscortFromQuest(iQuest, "RPG_COW");                              RegisterGoalEx(iQuest, "translate_Shepherd_Quest_Lead_Goal");       }
		else if ( nGiver == 20 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Woodcutter_Quest_Kill_Goal");     }
		else if ( nGiver == 21 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Woodcutter_Quest_Special_Goal");  }
		else if ( nGiver == 22 ) { CreateKillBringQuest(iQuest, "RPG_Witch_Kill");                        RegisterGoalEx(iQuest, "translate_Witch_Quest_Kill_Goal");          }
		else if ( nGiver == 23 ) { CreateBringQuest(iQuest, "RPG_Spearman_Bring");                        RegisterGoalEx(iQuest, "translate_Spearman_Quest_Bring_Goal");      }
		else if ( nGiver == 24 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Sorcerer_Quest_Kill2_Goal");      }
		else if ( nGiver == 25 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Sorcerer_Quest_Kill3_Goal");      }
		else if ( nGiver == 26 ) { CreateEscortFromQuest(iQuest, "NPC_PRIEST");                           RegisterGoalEx(iQuest, "translate_Sorcerer_Quest_Prisoner_Goal");   }
		else if ( nGiver == 27 ) { CreateDeliverQuest(iQuest, "RPG_Priest_Deliver", "NPC_PRIEST");        RegisterGoalEx(iQuest, "translate_Priest_Quest_Deliver_Goal");      }
		else if ( nGiver == 28 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Priest_Quest_Kill_Goal");         }
		else if ( nGiver == 29 ) { CreateKillTakeQuest(iQuest);                                           RegisterGoalEx(iQuest, "translate_Knight_Quest_KillTake_Goal");     }
		else if ( nGiver == 30 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Footman_Quest_Kill_Goal");        }
		else if ( nGiver == 31 ) { CreateKillTakeQuest(iQuest);                                           RegisterGoalEx(iQuest, "translate_Footman_Quest_KillTake_Goal");    }
		else if ( nGiver == 32 ) { CreateEscortFromQuest(iQuest, "DIPLOMAT");                             RegisterGoalEx(iQuest, "translate_Hunter_Quest_Prisoner_Goal");     }
		else if ( nGiver == 33 ) { CreateEscortFromQuest(iQuest, "NPC_SORCERER");                         RegisterGoalEx(iQuest, "translate_Hunter_Quest_Prisoner2_Goal");    }
		else if ( nGiver == 34 ) { CreateEscortFromQuest(iQuest, "NPC_SHEPHERD");                         RegisterGoalEx(iQuest, "translate_Hunter_Quest_Prisoner3_Goal");    }
		else if ( nGiver == 35 ) { CreateKillBringQuest(iQuest, "RPG_Hunter_Bring2");                     RegisterGoalEx(iQuest, "translate_Hunter_Quest_Bring2_Goal");       }
		else if ( nGiver == 36 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Shepherd_Quest_Kill2_Goal");      }
		else if ( nGiver == 37 ) { CreateEscortQuest(iQuest/*, "NPC_SHEPHERD", "NPC_SHEPHERD"*/);         RegisterGoalEx(iQuest, "translate_Shepherd_Quest_Escort_Goal");     }
		else if ( nGiver == 38 ) { CreateEscortFromQuest(iQuest, "RPG_WHITEWOLF");                        RegisterGoalEx(iQuest, "translate_Witch_Quest_Prisoner_Goal");      }
		else if ( nGiver == 39 ) { CreateKillBringQuest(iQuest, "RPG_Witch_Bring");                       RegisterGoalEx(iQuest, "translate_Witch_Quest_Bring_Goal");         }
		else if ( nGiver == 40 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Witch_Quest_Kill2_Goal");         }
		else if ( nGiver == 41 ) { CreateEscortQuest(iQuest/*, "NPC_OLDWITCH", "NPC_OLDWITCH"*/);         RegisterGoalEx(iQuest, "translate_Witch_Quest_Escort_Goal");        }
		else if ( nGiver == 42 ) { CreateEscortQuest(iQuest, "DIPLOMAT", "DIPLOMAT");                     RegisterGoalEx(iQuest, "translate_Diplomat_Quest_Escort2_Goal");    }
		else if ( nGiver == 43 ) { CreateEscortFromQuest(iQuest, "NPC_WOODCUTTER");                       RegisterGoalEx(iQuest, "translate_Diplomat_Quest_Prisoner_Goal");   }
		else if ( nGiver == 44 ) { CreateKillTakeQuest(iQuest);                                           RegisterGoalEx(iQuest, "translate_Diplomat_Quest_KillTake_Goal");   }
		else if ( nGiver == 45 ) { CreateEscortQuest(iQuest/*, "NPC_PRIESTESS", "NPC_PRIESTESS"*/);       RegisterGoalEx(iQuest, "translate_Priestessa_Quest_Escort_Goal");   }
		else if ( nGiver == 46 ) { CreateDeliverQuest(iQuest, "RPG_Priestessa_Deliver", "NPC_PRIESTESS"); RegisterGoalEx(iQuest, "translate_Priestessa_Quest_Deliver_Goal");  }
		else if ( nGiver == 47 ) { CreateEscortFromQuest(iQuest, "NPC_PRIESTESS");                        RegisterGoalEx(iQuest, "translate_Priestessa_Quest_Prisoner_Goal"); }
		else if ( nGiver == 48 ) { CreateKillTakeQuest(iQuest);                                           RegisterGoalEx(iQuest, "translate_Woodcutter_Quest_KillTake_Goal"); }
		else if ( nGiver == 49 ) { CreateKillTakeQuest(iQuest);                                           RegisterGoalEx(iQuest, "translate_Woodcutter_Quest_KillTake2_Goal");}
		else if ( nGiver == 50 ) { CreateBringQuest(iQuest, "RPG_Woodcutter_Bring");                      RegisterGoalEx(iQuest, "translate_Woodcutter_Quest_Bring_Goal");    }
		else if ( nGiver == 51 ) { CreateKillQuest(iQuest);                                               RegisterGoalEx(iQuest, "translate_Spearman_Quest_Kill_Goal");       }
		else if ( nGiver == 52 ) { CreateEscortFromQuest(iQuest, "NPC_SPEARMAN");                         RegisterGoalEx(iQuest, "translate_Spearman_Quest_Prisoner_Goal");   }
		else if ( nGiver == 53 ) { CreateEscortQuest(iQuest/*, "GADGET32"*/);                             RegisterGoalEx(iQuest, "translate_Spearman_Quest_Escort_Goal");     }
		else if ( nGiver == 54 ) { CreateDeliverQuest(iQuest, "RPG_Spearman_Deliver", "NPC_SPEARMAN");    RegisterGoalEx(iQuest, "translate_Spearman_Quest_Deliver_Goal");    }
		else __ASSERT_FALSE();

		if ( nGiver ==  3 ) // nagrobek dla dziadka
		{
			nRandNum = RAND(5);

			     if ( nRandNum == 0 ) CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "GADGET33");
			else if ( nRandNum == 1 ) CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "GADGET34");
			else if ( nRandNum == 2 ) CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "GADGET35");
			else if ( nRandNum == 3 ) CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "GADGET36");
			else if ( nRandNum == 4 ) CreateObject(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "GADGET37");
			else __ASSERT_FALSE();
		}
		else if ( nGiver == 11 ) // mag za footmanem
		{
			     if ( m_anQuestA[iQuest] ==   0 ) { dx =  0; dy =  1; }
			else if ( m_anQuestA[iQuest] ==  64 ) { dx = -1; dy =  0; }
			else if ( m_anQuestA[iQuest] == 128 ) { dx =  0; dy = -1; }
			else if ( m_anQuestA[iQuest] == 192 ) { dx =  1; dy =  0; }
			else __ASSERT_FALSE();

			SetRealImmortal(m_pNeutral2.CreateUnit(m_anQuestX[iQuest]+dx, m_anQuestY[iQuest]+dy, m_anQuestZ[iQuest], m_anQuestA[iQuest], "NPC_SORCERER"), true);
			
		}
		else if ( nGiver == 34 ) // drugi dzieciak lucznika
		{
			m_apEscort[iQuest] = CreateDirUnits(m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_SHEPHERD", 1, 0);

			SetRealImmortal(m_apEscort[iQuest], true);
		}
		else if ( nGiver == 37 ) // czekajacy na pastwisku
		{
			SetRealImmortal(m_pNeutral2.CreateUnit(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "NPC_SHEPHERD"), true);

			SetRealImmortal(m_pNeutral2.CreateUnit(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "RPG_COW"), true);
			SetRealImmortal(m_pNeutral2.CreateUnit(m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], m_anQuestA[iQuest], "RPG_COW"), true);
		}
		else if ( nGiver == 52 ) // towarzysze broni wlucznika
		{
			m_apEscort[iQuest] = CreateDirUnits(m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_SPEARMAN", RAND(2), 0);
			CreateDirUnits(m_apEscort[iQuest],  m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_FOOTMAN" , RAND(2), 0);
			CreateDirUnits(m_apEscort[iQuest],  m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_HUNTER"  , RAND(2), 0);

			platTmp = m_apEscort[iQuest];
			if ( platTmp.GetUnitsCount() == 0 )
			{
				nRandNum = RAND(3);

				     if ( nRandNum == 0 ) CreateDirUnits(m_apEscort[iQuest], m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_SPEARMAN", 1, 0);
				else if ( nRandNum == 1 ) CreateDirUnits(m_apEscort[iQuest], m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_FOOTMAN" , 1, 0);
				else if ( nRandNum == 2 ) CreateDirUnits(m_apEscort[iQuest], m_pNeutral2, m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1, "NPC_HUNTER"  , 1, 0);
			}

			SetRealImmortal(m_apEscort[iQuest], true);
		}
		
		CloseQuestGate(iQuest);
		CloseQuestDoneGate(iQuest);

		m_anQuestReady.Add(iQuest);
	}
	function void InitializeQuests(int nFrom, int nTo)
	{
		int i;
		unitex uTmp;
		
		for ( i=nFrom; i<=nTo; ++i)
		{
			CreateQuest(i, CreateGiver(i));
		}
		
		#ifndef RPG_X_EC
			UpdateFindQuestGoal();
		#endif
	}
	function void ActivateQuest(int iQuest)
	{
		int nGiver;
		int nTmp;
		int nExp, nUnits;
		unitex uHero;
		unitex uChest;
		platoon platTmp;

		int nOffX, nOffY;
		unitex uEscort;
		
		m_anQuestActive.Add(iQuest); // ActivateQuest po koncu dialogu (BUGFIX 1519); INFO: miedzy poczatkiem a koncem dialogu quest nie jest nigdzie podpiety !

		nGiver = m_anQuestGiver[iQuest];

		uHero = m_auQuestHero[iQuest];
		nExp = uHero.GetExperienceLevel();
		
#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		if ( m_anQuestType[iQuest] == questBring )
		{
			m_anBringCount[iQuest] = 1;
			CreateArtefact(GetStringBuff(bufferBringArts+iQuest), m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], 0);
		}

		if ( m_anQuestType[iQuest] == questDeliver )
		{
			m_anBringCount[iQuest] = 1;
			uHero.AddToInventory(GetStringBuff(bufferBringArts+iQuest), m_anBringCount[iQuest], true);
		}

		if ( m_anQuestType[iQuest] == questEscort ) // zeby nie uciekal (i czasem jak nie ma miejsca glupio odwracal) od bohatera po wzieciu questa
		{
			uEscort = m_auEscort[iQuest];

			if ( IsUnitNearUnit(uEscort, uHero, 1) )
			{
				nOffX = uHero.GetLocationX() - uEscort.GetLocationX();
				nOffY = uHero.GetLocationY() - uEscort.GetLocationY();

				CommandMoveUnitToUnit(uEscort, uHero, 2*nOffX, 2*nOffY); // przejsc za bohatera
			}
		}

		if ( m_anQuestType[iQuest] == questKillTake )
		{
			nTmp = RAND(3);
			if ( nTmp == 0 ) uChest = CreateUnitAtQuest(m_pEnemy, iQuest, "CHEST1");
			if ( nTmp == 1 ) uChest = CreateUnitAtQuest(m_pEnemy, iQuest, "CHEST2");
			if ( nTmp == 2 ) uChest = CreateUnitAtQuest(m_pEnemy, iQuest, "CHEST3");

			uChest.CommandSetMovementMode(modeHoldPos);

			uChest.SetScriptData(797);
		}

		if ( m_anQuestType[iQuest] != questEscort )
		{
			m_apEnemy[iQuest] = CreateQuestEnemy(m_pEnemy, nGiver, nExp, GetHeroes(), m_anQuestX[iQuest], m_anQuestY[iQuest], m_anQuestZ[iQuest], -1);
		}

		if ( m_anQuestType[iQuest] == questKillBring )
		{
			platTmp = m_apEnemy[iQuest];
			m_anBringCount[iQuest] = platTmp.GetUnitsCount();
		}

		if ( m_anQuestType[iQuest] == questKillTake )
		{
			platTmp = m_pEnemy.CreatePlatoon();
			platTmp.EnableFeatures(disposeIfNoUnits,true);

			platTmp.AddUnitToPlatoon(uChest.GetUnitRef());

			m_apEnemy[iQuest] = platTmp;
		}

		m_apGuard[iQuest] = CreateQuestGuard(m_pEnemy, nGiver, nExp, GetHeroes(), m_anQuestGuardX[iQuest], m_anQuestGuardY[iQuest], m_anQuestGuardZ[iQuest], m_anQuestGuardA[iQuest]);
	}
	function int UpdateReadyQuest(int iQuest, unitex uHero)
	{
		// ASSERT( IsIntInArray(m_anQuestReady, iQuest) );
		ASSERT( uHero != null && uHero.IsLive() );
		
		if ( IsUnitNearUnit(uHero, m_auTalker[iQuest], rangeStartTalk ) )
		{
			m_abStopTalk[iQuest] = false;
			
			if (  m_auTalkerSmoke[iQuest] == null )
			{
				StartTalk(iQuest);
			}
			if ( IsUnitNearUnit(uHero, m_auTalker[iQuest], rangeTalk) && !uHero.IsMoving() )
			{
				StopTalk(iQuest);
				VERIFY( RemoveUnitFromArray(m_auHeroReady, uHero) );
				m_auQuestHero[iQuest] = uHero;
				VERIFY( RemoveIntFromArray(m_anQuestReady, iQuest) );
				#ifndef RPG_X_EC
					UpdateFindQuestGoal();

					UpdateReadyQuestMarker(uHero, -1);
				#endif
				
				     if ( m_anQuestType[iQuest] == questBring      ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 0, -1);
				else if ( m_anQuestType[iQuest] == questKill       ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 1, -1);
				else if ( m_anQuestType[iQuest] == questEscort     ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 0, -1);
				else if ( m_anQuestType[iQuest] == questEscortFrom ) AddWorldMapSignAtQuestGiver(m_auQuestHero[iQuest], iQuest, 0, -1);
				else if ( m_anQuestType[iQuest] == questDeliver    ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 0, -1);
				else if ( m_anQuestType[iQuest] == questKillTake   ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 1, -1);
				else if ( m_anQuestType[iQuest] == questKillBring  ) AddWorldMapSignAtQuest(m_auQuestHero[iQuest], iQuest, 1, -1);
				else __ASSERT_FALSE();
								
				PlayStartDialog(iQuest);
				
				return true;
			}
		}
		
		return false;
	}
	function int UpdateActiveQuest(int iQuest)
	{
		platoon platTmp;
		// unitex uUnit;
		unitex uHero;
		unitex uEscort;
		unitex uEscortTo;
		int nOffX, nOffY;
		int x, y, z;

		int bNearEnemy;
		
		// ASSERT( IsIntInArray(m_anQuestActive, iQuest) );
		
		uHero = m_auQuestHero[iQuest];
		
		platTmp = m_apGuard[iQuest];
		if ( platTmp.GetUnitsCount() == 0 )
		{
			OpenQuestGate(iQuest);
		}
		
		if ( m_anQuestType[iQuest] == questBring || m_anQuestType[iQuest] == questKillBring )
		{
			if ( uHero.CountInventory(GetStringBuff(bufferBringArts+iQuest)) >= m_anBringCount[iQuest] )
			{
				VERIFY( RemoveIntFromArray(m_anQuestActive, iQuest) );
				m_anQuestDone.Add(iQuest);
				
				ASSERT( m_auTalker[iQuest] != null );
				
				RemoveWorldMapSignAtQuest(uHero, iQuest);
				AddWorldMapSignAtQuestGiver(uHero, iQuest, 0, -1);
				
				return true;
			}
		}
		else if ( m_anQuestType[iQuest] == questKill )
		{
			platTmp = m_apEnemy[iQuest];
			if ( platTmp.GetUnitsCount() == 0 )
			{
				VERIFY( RemoveIntFromArray(m_anQuestActive, iQuest) );
				m_anQuestDone.Add(iQuest);
				
				ASSERT( m_auTalker[iQuest] != null );
				
				RemoveWorldMapSignAtQuest(uHero, iQuest);
				AddWorldMapSignAtQuestGiver(uHero, iQuest, 0, -1);
				
				return true;
			}
		}
		else if ( m_anQuestType[iQuest] == questEscort || m_anQuestType[iQuest] == questEscortFrom )
		{
			uEscort = m_auEscort[iQuest];
			x = uEscort.GetLocationX();
			y = uEscort.GetLocationY();
			z = uEscort.GetLocationZ();

			bNearEnemy = IsUnitNearPoint(x, y, z, rangeNear, m_pEnemy.GetIFF());

			if ( IsUnitNearUnit(uEscort, m_auEscortTo[iQuest], rangeNear) )
			{
				if ( !uEscort.IsMoving() )
				{
					m_auTalker[iQuest] = m_auSpecial[iQuest];
					
					VERIFY( RemoveIntFromArray(m_anQuestActive, iQuest) );
					m_anQuestDone.Add(iQuest);

					// TO_DO: Remove uEscortTo Unit // gdy postac idzie do miejsca a nie do kogos
					
					OpenQuestGate(iQuest); // na wszelki wypadek
					
					return true;
				}
			}
			else if ( IsUnitNearUnit(uEscort, m_auEscortTo[iQuest], 8) )
			{
				// platTmp = m_apGuard[iQuest];
				// if ( platTmp.GetUnitsCount() == 0 || m_anQuestType[iQuest] == questEscortFrom )
				// {
				uEscortTo = m_auEscortTo[iQuest];
				x = uEscortTo.GetLocationX();
				y = uEscortTo.GetLocationY();
				z = uEscortTo.GetLocationZ();
				if ( !bNearEnemy && !IsUnitNearPoint(x, y, z, rangeNear, m_pEnemy.GetIFF()) )
				{
					nOffX = 0;
					nOffY = 0;
					
						 if ( uEscort.GetLocationX() < uEscortTo.GetLocationX() ) nOffX = -3;
					else if ( uEscort.GetLocationX() > uEscortTo.GetLocationX() ) nOffX = +3;
					else if ( uEscort.GetLocationY() < uEscortTo.GetLocationY() ) nOffY = -3;
					else if ( uEscort.GetLocationY() > uEscortTo.GetLocationY() ) nOffY = +3;

					CommandMoveUnitToUnit(uEscort, uEscortTo);
					if ( m_apEscort[iQuest] != null ) CommandMovePlatoonToUnit(m_apEscort[iQuest], uEscortTo, nOffX, nOffY);
				}
				// }
			}
			else if ( IsUnitNearUnit(uEscort, uHero, 1) )
			{
				if ( !uEscort.IsMoving() && !uHero.IsMoving() )
				{
					nOffX = uEscort.GetLocationX() - uHero.GetLocationX();
					nOffY = uEscort.GetLocationY() - uHero.GetLocationY();

					uEscort.BeginQuickRecord();
					CommandMoveUnitToUnit(uEscort, uEscort, nOffX, nOffY); // odsunac sie od bohatera
					uEscort.CommandTurn(uEscort.GetAngleToTarget(uHero.GetUnitRef()));
					uEscort.EndQuickRecord();
				}
			}
			else if ( IsUnitNearUnit(uEscort, uHero, 2) )
			{
				// nic nie robimy, zeby nie resetowac animacji nudy
			}
			else if ( IsUnitNearUnitIgnoreZ(uEscort, uHero, rangeFollow) )
			{
				if ( !uHero.IsInTower() )
				{
					x = uHero.GetLocationX();
					y = uHero.GetLocationY();
					z = uHero.GetLocationZ();
					if ( !bNearEnemy && !IsUnitNearPoint(x, y, z, rangeNear, m_pEnemy.GetIFF()) )
					{
						nOffX = 0;
						nOffY = 0;
						
						     if ( uEscort.GetLocationX() < uHero.GetLocationX() ) nOffX = -2;
						else if ( uEscort.GetLocationX() > uHero.GetLocationX() ) nOffX = +2;
						else if ( uEscort.GetLocationY() < uHero.GetLocationY() ) nOffY = -2;
						else if ( uEscort.GetLocationY() > uHero.GetLocationY() ) nOffY = +2;
						
						CommandMoveUnitToUnit(uEscort, uHero, nOffX, nOffY);

						if ( m_apEscort[iQuest] != null ) CommandMovePlatoonToUnit(m_apEscort[iQuest], uHero, nOffX, nOffY);
					}
				}
			}
			else if ( m_nEscortMarkerTick == 0 )
			{
				ASSERT( uEscort != null );
				
				AddWorldMapSignAtUnit(uHero, uEscort, 0, constMarkerUpdateTicks*constWorkingTickTime);
			}
		}
		else if ( m_anQuestType[iQuest] == questDeliver )
		{
//			if ( uHero.CountInventory(GetStringBuff(bufferBringArts+iQuest)) )
//			{
				VERIFY( RemoveIntFromArray(m_anQuestActive, iQuest) );
				m_anQuestDone.Add(iQuest);
				
				m_auTalker[iQuest] = m_auSpecial[iQuest];

				ASSERT( m_auTalker[iQuest] != null );
				
				return true;
//			}
		}
		else if ( m_anQuestType[iQuest] == questKillTake )
		{
			platTmp = m_apEnemy[iQuest];
			if ( platTmp.GetUnitsCount() == 0 )
			{
				VERIFY( RemoveIntFromArray(m_anQuestActive, iQuest) );
				m_anQuestDone.Add(iQuest);
				
				ASSERT( m_auTalker[iQuest] != null );
				
				RemoveWorldMapSignAtQuest(uHero, iQuest);
				
				return true;
			}
		}
		
		return false;
	}
	function int UpdateDoneQuest(int iQuest)
	{
		unitex uHero, uHeroSmoke;
		int nIFFNum;
		player pPlayer;
		unitex uTalker;
		
		// ASSERT( IsIntInArray(m_anQuestDone, iQuest) );
		ASSERT( m_auTalker[iQuest] != null );
		
		uHero = m_auQuestHero[iQuest];

		if ( m_anQuestType[iQuest] == questKillTake )
		{
			nIFFNum = uHero.GetIFFNumber();
			pPlayer = GetPlayer(nIFFNum);

			VERIFY( RemoveIntFromArray(m_anQuestDone, iQuest) );
				
			++m_anPlayerQuestsDone[nIFFNum];

			OpenQuestDoneGate(iQuest);
			
			m_auHeroReady.Add(uHero);
			
			SetGoalStateEx(pPlayer, iQuest, goalAchieved);
			
			OnQuestDoneExpAdd(uHero);

			uTalker = m_auTalker[iQuest];
			uTalker.SetIsQuestGiverUnit(false);
			
			#ifndef RPG_X_EC
				if ( m_anQuestReady.GetSize() > 0 ) pPlayer.EnableGoal(goalFindQuest, true);
			#endif

			return true;
		}
		
		if ( IsUnitNearUnit(uHero, m_auTalker[iQuest], rangeStartTalk) )
		{
			if (  m_auTalkerSmoke[iQuest] == null )
			{
				if ( (m_anQuestType[iQuest] != questBring && m_anQuestType[iQuest] != questDeliver && m_anQuestType[iQuest] != questKillBring) || uHero.CountInventory(GetStringBuff(bufferBringArts+iQuest)) >= m_anBringCount[iQuest] )
				{
					StartTalk(iQuest);
				}
			}
			else if ( IsUnitNearUnit(uHero, m_auTalker[iQuest], rangeTalk) && !uHero.IsMoving() )
			{
				nIFFNum = uHero.GetIFFNumber();
				
				StopTalk(iQuest);
				
				VERIFY( RemoveIntFromArray(m_anQuestDone, iQuest) );
				
				++m_anPlayerQuestsDone[nIFFNum];
				
				     if ( m_anQuestType[iQuest] == questEscort  ) RemoveWorldMapSignAtQuest(uHero, iQuest);
				else if ( m_anQuestType[iQuest] == questDeliver ) RemoveWorldMapSignAtQuest(uHero, iQuest);
				else                                              RemoveWorldMapSignAtQuestGiver(uHero, iQuest);

				if ( m_anQuestType[iQuest] == questBring || m_anQuestType[iQuest] == questDeliver || m_anQuestType[iQuest] == questKillBring )
				{
					uHero.AddToInventory(GetStringBuff(bufferBringArts+iQuest), m_anBringCount[iQuest], false);
				}
				
				uHeroSmoke = m_auPlayerHeroSmoke[nIFFNum];
				if ( uHeroSmoke )
				{
					uHeroSmoke.RemoveUnit();
					m_auPlayerHeroSmoke[nIFFNum] = null;
				}
				
				PlayEndDialog(iQuest);
				OpenQuestDoneGate(iQuest);
				
				return true;
			}
		}
		else if (  m_auTalkerSmoke[iQuest] != null )
		{
			StopTalk(iQuest);
		}
		
		return false;
	}
	function void UpdateQuests()
	{
		int i, j, n, m;
		unitex uHero;
		int iQuest;
		player pPlayer;
		
		m = m_auHeroReady.GetSize();
		for (j=0; j<m; ++j)
		{
			uHero = m_auHeroReady[j];
			ASSERT(uHero != null);
			
			if ( !uHero.IsLive() )
			{
				m_auHeroReady.RemoveAt(j);
				--m; --j;
				continue;
			}
			
			n = m_anQuestReady.GetSize();
			for (i=0; i<n; ++i)
			{
				if ( UpdateReadyQuest(m_anQuestReady[i], uHero) )
				{
					--m; --j;
					break;
				}
			}
		}
		
		n = m_anQuestReady.GetSize();
		for (i=0; i<n; ++i)
		{
			iQuest = m_anQuestReady[i];
			
			if ( m_abStopTalk[iQuest] && m_auTalkerSmoke[iQuest] != null )
			{
				StopTalk(iQuest);
			}
			
			m_abStopTalk[iQuest] = true;
		}
		
		n = m_anQuestActive.GetSize();
		for (i=0; i<n; ++i)
		{
			j = m_anQuestActive[i];
			uHero = m_auQuestHero[j];
			ASSERT(uHero != null);
			
			if ( !uHero.IsLive() )
			{
				pPlayer = GetPlayer(uHero.GetIFFNumber());
				if ( pPlayer == null || !pPlayer.IsAlive() )
				{
					m_anQuestActive.RemoveAt(i);
					--n; --i;

					OpenQuestDoneGate(j);
				}

				continue;
			}
			
			if ( UpdateActiveQuest(j) )
			{
				--n; --i;
				continue;
			}
		}
		
		n = m_anQuestDone.GetSize();
		for (i=0; i<n; ++i)
		{
			j = m_anQuestDone[i];
			uHero = m_auQuestHero[j];
			ASSERT(uHero != null);
			
			if ( !uHero.IsLive() )
			{
				pPlayer = GetPlayer(uHero.GetIFFNumber());
				if ( pPlayer == null || !pPlayer.IsAlive() )
				{
					m_anQuestActive.RemoveAt(i);
					--n; --i;

					OpenQuestDoneGate(j);
				}

				continue;
			}
			
			if ( UpdateDoneQuest(j) )
			{
				--n; --i;
				continue;
			}
		}
	}
	/*
	function void InitializeUnits()
	{
		int i;
		player pPlayer;
		unitex uHero;
		for ( i=0; i<constMaxPlayers; ++i )
		{
			pPlayer = GetPlayer(i);
			
			if ( pPlayer != null )
			{
				// TO_DO: Create Hero
				
				pPlayer.SetScriptData(dataLastArtifact, -1);
				pPlayer.SetScriptData(dataQuestMarker, -1);
				
				m_auHero.Add(uHero);
				m_auHeroReady.Add(uHero);
				
				pPlayer.CameraFollowObject(uHero);
				pPlayer.SelectUnit(uHero, false);
				
				pPlayer.EnableGoal(goalFindQuest, true);
			}
		}
	}
	/**/
	function void UpdateHeros()
	{
		int i, n, q;
		unitex uHero;
		int nHeroOldX, nHeroOldY, nHeroOldZ;
		int nHeroX, nHeroY, nHeroZ;
		int nIFFNum;
		player pPlayer;
		
		int nHeroType, nExp;

		unitex uHireling, uHirelingSmoke;

		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			
			nHeroX = uHero.GetLocationX();
			nHeroY = uHero.GetLocationY();
			nHeroZ = uHero.GetLocationZ();
			
			nIFFNum = uHero.GetIFFNumber();
			
			nHeroOldX = m_anPlayerHeroX[nIFFNum];
			nHeroOldY = m_anPlayerHeroY[nIFFNum];
			nHeroOldZ = m_anPlayerHeroZ[nIFFNum];
			
			pPlayer = GetPlayer(nIFFNum);
			
			if ( Distance(nHeroX, nHeroY, nHeroOldX, nHeroOldY) > rangeCameraFollow || nHeroZ != nHeroOldZ )
			{
				if (!pPlayer.IsCameraFollowingObject(uHero) && pPlayer.GetNumberOfUnits() == 1)
				{
					PlayerLookAtUnit(pPlayer, uHero, -1, -1, -1);
				}
			}
			
			m_anPlayerHeroX[nIFFNum] = nHeroX;
			m_anPlayerHeroY[nIFFNum] = nHeroY;
			m_anPlayerHeroZ[nIFFNum] = nHeroZ;

			if (uHero != null)
			{
				nHeroType = nHeroType | (1 << (uHero.GetRPGCharacterType()-1));
				if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		ASSERT( m_auHireling.GetSize() == m_auHirelingSmoke.GetSize() );
		
		n = m_auHireling.GetSize();
		for (i=0; i<n; ++i)
		{
			uHireling = m_auHireling[i];
			uHirelingSmoke = m_auHirelingSmoke[i];

			if ( !uHireling.IsLive() )
			{
				m_auHireling.RemoveAt(i);
				m_auHirelingSmoke.RemoveAt(i);
				--i; --n;
				continue;
			}

			if ( uHireling.GetIFF() == m_pNeutral.GetIFF() )
			{
				if ( uHirelingSmoke == null )
				{
					m_auHirelingSmoke[i] = CreateSmokeObject(uHireling, "TALK_HIRE");
				}
			}
			else
			{
				if ( uHirelingSmoke != null )
				{
					uHirelingSmoke.RemoveUnit();
					m_auHirelingSmoke[i] = null;
				}
			}

			if ( uHireling.GetExperienceLevel() < nExp + 1 )
			{
				uHireling.SetExperienceLevel(nExp + 1);
				uHireling.AutoAttachPointsToSkills();
			}
		}


		#ifndef RPG_X_EC
			if ( m_nQuestMarkerTick == 0 )
			{
				n = m_auHeroReady.GetSize();
				for (i=0; i<n; ++i)
				{
					uHero = m_auHeroReady[i];
					
					if ( m_anQuestReady.GetSize() > 0 )
					{
						q = m_anQuestReady[RAND(m_anQuestReady.GetSize())];
						UpdateReadyQuestMarker(uHero, q);
					}
				}
			}
		#endif
	}
	
	event EndTalk(int nIFFNum)
		{
		player pPlayer;

		#ifdef RPG_X_EC
			if ( RPGX_EndTalk(nIFFNum) )
			{
				return;
			}
		#endif RPG_X_EC

		pPlayer = GetPlayer(nIFFNum);
		if (pPlayer != null)
			{
			pPlayer.PrepareInterfaceToTalk(false, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_SIZE, INTERFACE_BORDERS_COLOR);
			}
		}
	event EndPrepareInterfaceToTalk(int bStartTalk, int nIFFNum)
		{
		player pPlayer;
		int iQuest;
		unitex uTalker, uHero;

		#ifdef RPG_X_EC
			if ( RPGX_EndPrepareInterfaceToTalk(bStartTalk, nIFFNum) )
			{
				return;
			}
		#endif RPG_X_EC
		
		iQuest = m_anPlayerQuest[nIFFNum];

		if ( iQuest == -1 )
		{
			return;
		}
		
		uTalker = m_auTalker[iQuest];
		uHero = m_auQuestHero[iQuest];

		SetRespawnHere(uHero);
		
		pPlayer = GetPlayer(nIFFNum);
		if (pPlayer != null)
			{
			if (bStartTalk)
				{
				// PlayerLookAtUnit(pPlayer, uTalker, constLookAtHeight, -1, constLookAtView); // bo czasem kamera gdzies uciekala

				pPlayer.PlayTalkDefinition();
				}
			else
				{
				uTalker.CommandSetTalkMode(false, true, false);
				uHero.CommandSetTalkMode(false, true, true);
				
				uHero.CommandSetMovementMode(pPlayer.GetScriptData(dataMovementMode));
				uTalker.CommandSetMovementMode(modeMove);
				
				/*
				if ( !(m_anQuestType[iQuest] == questEscort && IsGoalEnabledEx(iQuest)) ) // bo matka uciekala od przyprowadzonego do niej dziecka
				{
					// nie musza wracac na miejsce, bo juz nie ganiaja za wrogami
				}
				*/
				
				if ( IsGoalEnabledEx(iQuest) )
					{
					m_auHeroReady.Add(uHero);
					
					SetGoalStateEx(pPlayer, iQuest, goalAchieved);
					CreatePrize(iQuest);

					OnQuestDoneExpAdd(uHero);

					uTalker = m_auTalker[iQuest];
					uTalker.SetIsQuestGiverUnit(false);

					#ifndef RPG_X_EC
						if ( m_anQuestReady.GetSize() > 0 ) pPlayer.EnableGoal(goalFindQuest, true);

						if ( m_anQuestReady.GetSize()+m_anQuestActive.GetSize()+m_anQuestDone.GetSize() == 0 && m_auHero.GetSize() == m_auHeroReady.GetSize() )
						{
							SetStateDelay(150);

							state MissionComplete;
						}
					#endif
					}
				else
					{
					ActivateQuest(iQuest);

					#ifndef RPG_X_EC
						pPlayer.EnableGoal(goalFindQuest, false);
					#endif
					EnableGoalEx(pPlayer, iQuest, true);
					}
				}
			}
		}

	/****************************************************************************/

	#ifdef PRIZE_PROB_TEST
	function void PrizeProbTest()
	{
		int nPrizeType;
		int nHeroType;
		int nExp;

		TRACEF("PrizeProbTest...\n");

		for ( nPrizeType=1; nPrizeType<=0x10000; nPrizeType = nPrizeType << 4 )
		{
			TRACEF3("-- -- -- -- --", nPrizeType, "-- -- -- -- --");
			for ( nHeroType=1; nHeroType<128; nHeroType = nHeroType << 1 )
			{
				TRACEF(nHeroType);
				TRACEF(": ");
				for ( nExp=0; nExp<32; ++nExp )
				{
					CreatePrize(nHeroType, nPrizeType, nExp, 0, 0, 0, 0);
					TRACEF(", ");
				}
				TRACEF("\n");
			}
		}
	}
	#endif

	#ifdef QUESTS_TEST
	function void QuestsTest()
	{
		int nExp;
		int i;

		int nQuests;

		TRACEF("Quests Test...\n");

		for ( nExp=0; nExp<64; ++nExp )
		{
			TRACEF(nExp);
			TRACEF(": ");

			nQuests = 0;

			for ( i=0; i<constQuests; ++i )
			{
				if ( m_abGiverUsed[i] )
				{
					continue;
				}

				if ( GetMinLevel(i) > nExp || GetMaxLevel(i) < nExp )
				{
					continue;
				}

				++nQuests;
			}

			TRACEF(nQuests);
			TRACEF("\n");
		}
	}
	#endif

#define LOAD_ALLOWED(MarkerName, MarkerNum, Type) \
	LOAD(MarkerName, MarkerNum, # Type, m_anAllowed_ ## Type[RAND(m_anAllowed_ ## Type.GetSize())])

	state Initialize
	{
		player rPlayer, p2;
		int i, n;
		int j;
		unitex uShopUnit, uHero, uTeleport, uHirelingUnit;
		unitex auTeleports[];
		int anQuests[];
		int nQuest;
		int x, y, z, a;
		int nExp;
		int nSquad;
		int nRandNum;
		int bIsMagInGame;

		int nQuestArraySize;

		#ifdef PRIZE_PROB_TEST
			PrizeProbTest();
		#endif

		m_nHirelingLimit = 2;
		m_nPassivePrizeProbModifier = 0; // tak samo jak z potworow
		m_nPassivePrizeMonsterProbModifier = 0;

		m_nAddToMonstersLevel = 0;

		TRACEF("Initialize...\n");
		TRACE1("Initialize RPG");
		
		m_auHero.Create(0);
		m_auHeroReady.Create(0);
        m_auHeroDepot.Create(16);
        for (i = 0; i < 16; ++i)
        {
            m_auHeroDepot[i] = null;
        }
		m_anQuestReady.Create(0);
		m_anQuestActive.Create(0);
		m_anQuestDone.Create(0);
		
		m_anKilledX.Create(0);
		m_anKilledY.Create(0);
		m_anKilledZ.Create(0);
		
		m_anSafeArea.Create(0);

		m_auShop.Create(0);
		m_auHireling.Create(0);

		m_auShopSmoke.Create(0);
		m_auHirelingSmoke.Create(0);

		nQuestArraySize = constQuests;
		
		m_auQuestHero.Create(nQuestArraySize);
		m_auTalker.Create(nQuestArraySize);
		m_auTalkerSmoke.Create(nQuestArraySize);
		m_apGuard.Create(nQuestArraySize);
		m_apEnemy.Create(nQuestArraySize);
		m_apSpacial.Create(nQuestArraySize);
		m_auEscort.Create(nQuestArraySize);
		m_apEscort.Create(nQuestArraySize);
		m_auEscortTo.Create(nQuestArraySize);
		m_anQuestType.Create(nQuestArraySize);
		m_anQuestGiver.Create(nQuestArraySize);
		m_auSpecial.Create(nQuestArraySize);
		m_abStopTalk.Create(nQuestArraySize);
		m_abGiverUsed.Create(nQuestArraySize);
		
		m_anQuestGiverX.Create(nQuestArraySize);
		m_anQuestGiverY.Create(nQuestArraySize);
		m_anQuestGiverZ.Create(nQuestArraySize);
		m_anQuestGiverA.Create(nQuestArraySize);

		m_anQuestX.Create(nQuestArraySize);
		m_anQuestY.Create(nQuestArraySize);
		m_anQuestZ.Create(nQuestArraySize);
		m_anQuestA.Create(nQuestArraySize);

		m_anQuestGuardX.Create(nQuestArraySize);
		m_anQuestGuardY.Create(nQuestArraySize);
		m_anQuestGuardZ.Create(nQuestArraySize);
		m_anQuestGuardA.Create(nQuestArraySize);

		m_auGate.Create(nQuestArraySize);
		m_auQuestGate.Create(nQuestArraySize);
		m_auQuestDoneGate.Create(nQuestArraySize);

		m_anExGoalToGoalMap.Create(nQuestArraySize);

		m_anBringCount.Create(nQuestArraySize);

		m_anPlayerQuest.Create(constMaxPlayers);
		m_anPlayerHeroX.Create(constMaxPlayers);
		m_anPlayerHeroY.Create(constMaxPlayers);
		m_anPlayerHeroZ.Create(constMaxPlayers);
		
		m_anPlayerRespawnX.Create(constMaxPlayers);
		m_anPlayerRespawnY.Create(constMaxPlayers);
		m_anPlayerRespawnZ.Create(constMaxPlayers);

		m_anPlayerQuestsDone.Create(constMaxPlayers);
		m_anPlayerUnitsDestroyed.Create(constMaxPlayers);
		
		m_anNoEnemyX.Create(constMaxPlayers);
		m_anNoEnemyY.Create(constMaxPlayers);
		m_anNoEnemyZ.Create(constMaxPlayers);
		m_abNoEnemy.Create(constMaxPlayers);
		
		m_anPlayerLastGoal.Create(constMaxPlayers);
		
		m_auPlayerHeroSmoke.Create(constMaxPlayers);
		
		SetExperienceParams("EXPERIENCE_RPG_PARAM0");
		
		// InitializePlayers();
		// InitializeUnits();

		m_anEnemyX.Create(0);
		m_anEnemyY.Create(0);
		m_anEnemyZ.Create(0);

		m_anBonusX.Create(0);
		m_anBonusY.Create(0);
		m_anBonusZ.Create(0);

		m_anAllowed_RPG_BONUS.Create(0);
		m_anAllowed_RPG_HEALING.Create(0);
		m_anAllowed_RPG_HIRELING.Create(0);
		m_anAllowed_RPG_MANA.Create(0);
		m_anAllowed_RPG_SHOP.Create(0);
		m_anAllowed_RPG_TELEPORT.Create(0);
		m_anAllowed_RPG_QUEST.Create(0);
		m_anAllowed_RPG_QUEST_GIVER.Create(0);

		for ( i=1; i<=66; ++i ) m_anAllowed_RPG_BONUS.Add(i);
		for ( i=1; i<=56; ++i ) m_anAllowed_RPG_HEALING.Add(i);
		for ( i=1; i<=18; ++i ) m_anAllowed_RPG_HIRELING.Add(i);
		for ( i=1; i<=56; ++i ) m_anAllowed_RPG_MANA.Add(i);
		for ( i=1; i<=21; ++i ) m_anAllowed_RPG_SHOP.Add(i);
		for ( i=1; i<=20; ++i ) m_anAllowed_RPG_TELEPORT.Add(i);
		for ( i=1; i<=80; ++i ) m_anAllowed_RPG_QUEST.Add(i);
		for ( i=1; i<=80; ++i ) m_anAllowed_RPG_QUEST_GIVER.Add(i);

		m_pNeutral  = GetPlayer( 8);
		m_pNeutral1 = GetPlayer( 8);
		m_pNeutral2 = GetPlayer( 9);

		m_pEnemy    = GetPlayer(10);

		SetNeutrals(m_pNeutral1, m_pEnemy     );
		SetNeutrals(m_pNeutral2, m_pEnemy     );

		if ( GetPlayer(playerAnimals) != null )
		{
			SetNeutrals(m_pNeutral1, GetPlayer(playerAnimals));
			SetNeutrals(m_pNeutral2, GetPlayer(playerAnimals));
		}
		
		SetNeutrals(m_pNeutral1, m_pNeutral2  );

		EnableAssistant(0xffffff, false);

		auTeleports.Create(0);
		anQuests.Create(0);
		
		SetAllBridgesImmortal(true);
		//XXXMD 08.05.2003  - za szybko sie odtwarzaly potwory -------------------
		{ m_nRespawnOneOf = 5; m_nNoEnemyTrigerRange = 30; }
//		     if ( comboRespawnMonsters == 0) { m_nRespawnOneOf = 6; m_nNoEnemyTrigerRange = 30; }
//		else if ( comboRespawnMonsters == 1) { m_nRespawnOneOf = 3; m_nNoEnemyTrigerRange = 23; }
//		else if ( comboRespawnMonsters == 2) { m_nRespawnOneOf = 2; m_nNoEnemyTrigerRange = 15; }
       //XXXMD ------------------koniec

		#ifdef RPG_X_EC
			RPGX_Initialize();
		#endif RPG_X_EC

		InitializeQuests();

		bIsMagInGame = false;

		for(i=0;i<8;i=i+1)
		{
			rPlayer=GetPlayer(i);
			if(rPlayer!=null)
			{
				rPlayer.EnableAIFeatures(aiBNSendResult,false);//nie wysylac rezultatow do EARTH NETu
				rPlayer.EnableStatistics(false);
                rPlayer.SetDropSubObjectsOnKill(comboDropSubObjects);

                if (rPlayer.IsAlive())
                {
                    if (PointExist("MARKER_CHEST_DEPOT", i))
                    {
                        m_auHeroDepot[i] = rPlayer.CreateDepot(m_auHeroDepot[i], "CHEST_DEPOT", GetPointX("MARKER_CHEST_DEPOT", i), GetPointY("MARKER_CHEST_DEPOT", i), GetPointZ("MARKER_CHEST_DEPOT", i), GetPointAlpha("MARKER_CHEST_DEPOT", i));
                    }
				    uHero = rPlayer.CreateRPGCharacter(rPlayer.GetStartingPointX(),rPlayer.GetStartingPointY(),0,0);

				    m_anPlayerHeroX[i] = uHero.GetLocationX();
				    m_anPlayerHeroY[i] = uHero.GetLocationY();
				    m_anPlayerHeroZ[i] = uHero.GetLocationZ();

				    SetRespawnHere(uHero);

				    m_auHero.Add(uHero);
				    m_auHeroReady.Add(uHero);
				    
				    // rPlayer.CameraFollowObject(uHero);
				    rPlayer.SelectUnit(uHero, false);

				    if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();

				    if ( uHero.GetMaxMagic() > 0 ) bIsMagInGame = true;
                }
                else
                {
		            m_anPlayerRespawnX[i] = -1;
		            m_anPlayerRespawnY[i] = -1;
		            m_anPlayerRespawnZ[i] = -1;
                }

				rPlayer.SetScriptData(dataLastArtifact, -1);
				#ifndef RPG_X_EC
					rPlayer.SetScriptData(dataQuestMarker, -1);
				#endif
				rPlayer.SetScriptData(dataHeroExp, 0);

				m_anPlayerQuest[i] = -1;
				
				#ifndef RPG_X_EC
					rPlayer.EnableGoal(goalFindQuest, true);
				#endif

				SetNeutrals(rPlayer, m_pNeutral1);
				SetNeutrals(rPlayer, m_pNeutral2);

				for ( j=i+1; j<8; ++j )
				{
					p2 = GetPlayer(j);
					
					if ( p2 != null )
					{
						if ( rPlayer.IsEnemy(p2) || p2.IsEnemy(rPlayer) ) SetNeutrals(rPlayer, p2);
					}
				}
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		#ifdef QUESTS_TEST
			QuestsTest();
		#endif

		for ( i=0; i<constQuests; ++i )
		{
			if ( GetMinLevel(i) > nExp || GetMaxLevel(i) < nExp )
			{
				m_abGiverUsed[i] = true;
			}
		}

		for ( i=constFirstQuest; i<=constLastQuest; ++i )
		{
			if ( PointExist("MARKER_SHOP", i) )
			{
				if ( m_auHireling.GetSize() < m_nHirelingLimit && RAND(3) == 0 )
				{
					LOAD_ALLOWED("MARKER_SHOP", i, RPG_HIRELING)

					uHirelingUnit = GetUnit(GetPointX("MARKER_SHOP", i), GetPointY("MARKER_SHOP", i), GetPointZ("MARKER_SHOP", i));

					if ( uHirelingUnit != null )
					{
						InitializeHireling(uHirelingUnit);

						m_auHireling.Add(uHirelingUnit);
						m_auHirelingSmoke.Add(CreateSmokeObject(uHirelingUnit, "TALK_HIRE"));
					}
					else __ASSERT_FALSE();
				}
				else
				{
					LOAD_ALLOWED("MARKER_SHOP", i, RPG_SHOP)

					uShopUnit = GetLoadedShopUnit(m_pNeutral);

					if ( uShopUnit != null )
					{
						uShopUnit.SetSoldParams( 50, -100);
						uShopUnit.SetBuyParams (-50,  100);

						for ( j=1; j<=6; ++j )
						{
							if ( uShopUnit.GetShopType() == j ) { uShopUnit.SetArtefactBuyPriceModifier (j,  25-10+RAND(21)); uShopUnit.SetArtefactSoldPriceModifier (j, -25-10+RAND(21)); }
							if ( uShopUnit.GetShopType() != j ) { uShopUnit.SetArtefactBuyPriceModifier (j, -25-10+RAND(21)); uShopUnit.SetArtefactSoldPriceModifier (j,  25-10+RAND(21)); }
						}

						uShopUnit.SetArtefactBuyPriceModifier (7, -98);
						uShopUnit.SetArtefactSoldPriceModifier(7, -33);

						SetRealImmortal(uShopUnit, true);
						uShopUnit.CommandSetMovementMode(modeHoldPos);

						InitializeShop(uShopUnit, 8);

						m_auShop.Add(uShopUnit);
						m_auShopSmoke.Add(CreateSmokeObject(uShopUnit, "TALK_SHOP"));
					}
					else __ASSERT_FALSE();
				}
			}
			LOAD_ALLOWED("MARKER_BONUS", i, RPG_BONUS)
			if ( PointExist("MARKER_BONUS", i) )
			{
				x = GetPointX("MARKER_BONUS", i);
				y = GetPointY("MARKER_BONUS", i);
				z = GetPointZ("MARKER_BONUS", i);

				m_anBonusX.Add( x );
				m_anBonusY.Add( y );
				m_anBonusZ.Add( z );
			}
			if ( bIsMagInGame || IsAllowDynamicConnection())
			{
				LOAD_ALLOWED("MARKER_HEALING", i, RPG_MANA)
			}
			else
			{
				LOAD_ALLOWED("MARKER_HEALING", i, RPG_HEALING)
			}
			LOAD_ALLOWED("MARKER_TELEPORT", i, RPG_TELEPORT)
			if ( PointExist("MARKER_TELEPORT", i) )
			{
				auTeleports.Add(GetLoadedTeleport(m_pNeutral));
			}
			else
			{
				n = auTeleports.GetSize();
				if ( n > 1 ) for (j=0; j<n; ++j)
				{
					uTeleport = auTeleports[j];
					nRandNum = RAND(n-1);
					if ( nRandNum == j ) nRandNum = n-1;
					uTeleport.SetTeleportDestination(auTeleports[nRandNum]);
				}
				auTeleports.RemoveAll();
			}
			if ( PointExist("MARKER_ENEMY", i) )
			{
				x = GetPointX("MARKER_ENEMY", i);
				y = GetPointY("MARKER_ENEMY", i);
				z = GetPointZ("MARKER_ENEMY", i);
				m_anEnemyX.Add( x );
				m_anEnemyY.Add( y );
				m_anEnemyZ.Add( z );
			}
			if ( PointExist("MARKER_GATE_SPECIAL", i) )
			{
				x = GetPointX("MARKER_GATE_SPECIAL", i);
				y = GetPointY("MARKER_GATE_SPECIAL", i);
				z = GetPointZ("MARKER_GATE_SPECIAL", i);

				m_auQuestDoneGate[i] = GetUnit(x, y, z);
			}
			if ( PointExist("MARKER_QUEST_GIVER", i) && PointExist("MARKER_QUEST", i) )
			{
				x = GetPointX("MARKER_QUEST_GIVER", i);
				y = GetPointY("MARKER_QUEST_GIVER", i);
				z = GetPointZ("MARKER_QUEST_GIVER", i);
				a = GetPointAlpha("MARKER_QUEST_GIVER", i);

				m_anQuestGiverX[i] = x;
				m_anQuestGiverY[i] = y;
				m_anQuestGiverZ[i] = z;
				m_anQuestGiverA[i] = a;

				anQuests.Add(i);
			}
			else
			{
				j = i - 1;
				while ( anQuests.GetSize() > 0 )
				{
					nRandNum = RAND(anQuests.GetSize());
					nQuest = anQuests[nRandNum];

					anQuests.RemoveAt(nRandNum);

					x = GetPointX("MARKER_QUEST", nQuest);
					y = GetPointY("MARKER_QUEST", nQuest);
					z = GetPointZ("MARKER_QUEST", nQuest);
					a = GetPointAlpha("MARKER_QUEST", nQuest);

					m_anQuestX[j] = x;
					m_anQuestY[j] = y;
					m_anQuestZ[j] = z;
					m_anQuestA[j] = a;

					if ( a == 0 )
					{
						m_anQuestGuardX[j] = x;
						m_anQuestGuardY[j] = y - 6;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 64 )
					{
						m_anQuestGuardX[j] = x + 6;
						m_anQuestGuardY[j] = y;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 128 )
					{
						m_anQuestGuardX[j] = x;
						m_anQuestGuardY[j] = y + 6;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else if ( a == 192 )
					{
						m_anQuestGuardX[j] = x - 6;
						m_anQuestGuardY[j] = y;
						m_anQuestGuardZ[j] = z;
						m_anQuestGuardA[j] = a;
					}
					else __ASSERT_FALSE();

					CreateQuest(j, CreateGiver(j));

					--j;
				}
				ASSERT( anQuests.GetSize() == 0 );
			}
			if ( PointExist("MARKER_GATE", i) )
			{
				x = GetPointX("MARKER_GATE", i);
				y = GetPointY("MARKER_GATE", i);
				z = GetPointZ("MARKER_GATE", i);

				m_auGate[i] = GetUnit(x, y, z);

				if ( PointExist("MARKER_SWITCH", i) )
				{
					CloseGate(i);

					x = GetPointX("MARKER_SWITCH", i);
					y = GetPointY("MARKER_SWITCH", i);
					z = GetPointZ("MARKER_SWITCH", i);

					CreateArtefact("SWITCH_1_1", x, y, z, maskGateOpenSwitch|i);
				}
				else
				{
					OpenGate(i);
				}
			}
		}

		// InitializeQuests(constFirstQuest, constLastQuest);
		#ifndef RPG_X_EC
			UpdateFindQuestGoal();
		#endif

		SetTimer(0, 10);
		SetTimer(1, 5*60*20);

		SetTimer(4, 1200);

        SetTimer(7, GetWindTimerTicks());
		StartWind();
		
		#ifdef RPG_X_EC
			RPGX_Start();
		#endif RPG_X_EC

		TRACEF("Working...\n");

		#ifdef RPGX_START_CUTSCENE
			return StartCutscene, 0;
		#endif

		return Working;
	}
		
	state Working
	{
		player pPlayer;
		int i;
		unitex uHero;
		
		UpdateQuests();
		UpdateHeros();
		UpdateEnemies();
		
		m_pNeutral1.SetMoney(0);
		m_pNeutral2.SetMoney(0);
		m_pEnemy.SetMoney(0);
		
		#ifdef DEBUG
			m_nDebugConsoleTick = (m_nDebugConsoleTick+1)%1;
			
			 // if ( m_nDebugConsoleTick == 0 ) SetConsoleText("qr=<%0> qa=<%1> qd=<%2> h=<%3> hr=<%4>", m_anQuestReady.GetSize(), m_anQuestActive.GetSize(), m_anQuestDone.GetSize(), m_auHero.GetSize(), m_auHeroReady.GetSize());
			 // if ( m_nDebugConsoleTick == 0 ) SetConsoleText("k=<%0> e=<%1> me=<%2>", m_anKilledX.GetSize(), GetHeroesExp(), GetHeroesMaxExp());
		#endif
		
		m_nEscortMarkerTick = (m_nEscortMarkerTick+1) % constMarkerUpdateTicks;
		#ifndef RPG_X_EC
			m_nQuestMarkerTick  = (m_nQuestMarkerTick +1) % constQuestMarkerTicks;
		#endif
		
		#ifdef RPG_X_EC
			RPGX_Working();
		#endif RPG_X_EC

		return Working, constWorkingTickTime;
	}

	state MissionComplete
	{
		EndGame(null);
	}

	event ResetFog(int nIFF)
	{
		int i, n;
		int j, m;
		int nExp;
		unitex uHero;
		int x, y, z;
		int nTmp;
		unitex uEnemy;
		int nMonsters;

		nIFF = nIFF & 0xff; // tylko fog graczy

		if ( nIFF == 0 ) return;

		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];

			if (uHero != null)
			{
				if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
			}
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		m = m_anEnemyX.GetSize();
		for (j=0; j<m; ++j)
		{
			x = m_anEnemyX[j];
			y = m_anEnemyY[j];
			z = m_anEnemyZ[j];

			if ( IsPointLocatedByAnyPlayer(x, y, z, nIFF) )
			{
				TRACE4("Monsters created:", x, y, z);

				nMonsters = n + comboRespawnMonsters;

				for (i=0; i<nMonsters; ++i) CreateMonster(m_pEnemy, nExp, x, y, z, m_nAddToMonstersLevel);

				m_anEnemyX.RemoveAt(j);
				m_anEnemyY.RemoveAt(j);
				m_anEnemyZ.RemoveAt(j);
				--j; --m;
			}
		}

		m = m_anBonusX.GetSize();
		for (j=0; j<m; ++j)
		{
			x = m_anBonusX[j];
			y = m_anBonusY[j];
			z = m_anBonusZ[j];

			if ( IsPointLocatedByAnyPlayer(x, y, z, nIFF) )
			{
				TRACE4("Bonus created:", x, y, z);

				nTmp = RAND(3);
				if ( nTmp == 0 ) uEnemy = m_pEnemy.CreateUnit(x, y, z, 0, "CHEST1");
				if ( nTmp == 1 ) uEnemy = m_pEnemy.CreateUnit(x, y, z, 0, "CHEST2");
				if ( nTmp == 2 ) uEnemy = m_pEnemy.CreateUnit(x, y, z, 0, "CHEST3");

				uEnemy.CommandSetMovementMode(modeHoldPos);

				uEnemy.SetScriptData(777);

				CreateBonusEnemy(m_pEnemy, nExp, GetHeroes(), x, y, z, m_nAddToMonstersLevel);

				m_anBonusX.RemoveAt(j);
				m_anBonusY.RemoveAt(j);
				m_anBonusZ.RemoveAt(j);
				--j; --m;
			}
		}
	}

	event Artefact(int nArtefactNum, unitex uUnitOnArtefact, player pPlayerOnArtefact)
	{
		int nGate;
		int nIFFNum;
		int iQuest;
		
		if ( nArtefactNum == -1 ) return false; // gdyby jakis byl wstawiony na mapie
		if ( nArtefactNum ==  0 ) return false;
		
		nIFFNum = uUnitOnArtefact.GetIFFNumber();
		
		if ( nIFFNum >= 0 && nIFFNum < constMaxPlayers )
		{
			// TRACE2("Artefact:", nArtefactNum);
			
			if ( nArtefactNum & maskGateOpenSwitch )
			{
				nGate = nArtefactNum & ~maskGateOpenSwitch;
				OpenGate(nGate);
				
				CreateArtefactAtUnit("SWITCH_1_2", uUnitOnArtefact, 0);
				
				return true;
			}
			/*
			if ( nArtefactNum & maskBring )
			{
				iQuest = nArtefactNum & ~maskBring;
				if ( uUnitOnArtefact == m_auQuestHero[iQuest] )
				{
					m_anQuestDone.Add( iQuest );

					return false;
				}
			}
			*/
		}
		
		#ifdef RPG_X_EC
			if ( RPGX_Artefact(nArtefactNum, uUnitOnArtefact, pPlayerOnArtefact) )
			{
				return true;
			}
		#endif RPG_X_EC

		return false;
	}

    event PassiveDestroyed(unitex uPassive, unitex uShooter) // #passiveEventBarrel
    {
		unitex uHero;
		int nExp, nHeroType;
		int i, n;

		int x, y, z;

		int nMonsterProbModifier;

		if ( IsUnitInArray(m_auHero, uShooter) )
		{
			nExp = uShooter.GetExperienceLevel();
			nHeroType = 1 << (uShooter.GetRPGCharacterType()-1);

			uHero = uShooter;
		}
		else
		{
			n = m_auHero.GetSize();
			for (i=0; i<n; ++i)
			{
				uHero = m_auHero[i];

				if (uHero != null)
				{
					nHeroType = nHeroType | (1 << (uHero.GetRPGCharacterType()-1));
					if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
				}
			}

			uHero = null;
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		#ifdef RPG_X_EC
			if ( RPGX_PassiveDestroyed(uPassive, uHero) )
			{
				return;
			}
		#endif RPG_X_EC

		x = uPassive.GetLocationX();
		y = uPassive.GetLocationY();
		z = uPassive.GetLocationZ();

		if ( IsUnitNearPoint(x, y, z, rangeNear, m_pNeutral1.GetIFF()|m_pNeutral2.GetIFF()) )
		{
			nMonsterProbModifier = 300;
		}
		else
		{
			nMonsterProbModifier = 0;
		}

		if ( uHero != null )
		{
			CreatePrize       (          nHeroType, prizeBarrel, nExp, m_nPassivePrizeProbModifier                               + uHero.GetRPGSkillArtefacts(), x, y, z);
			CreatePrizeMonster(m_pEnemy, nHeroType, prizeBarrel, nExp, m_nPassivePrizeMonsterProbModifier + nMonsterProbModifier - uHero.GetRPGSkillArtefacts(), x, y, z);
		}
		else
		{
			CreatePrize       (          nHeroType, prizeBarrel, nExp, m_nPassivePrizeProbModifier                              , x, y, z);
			CreatePrizeMonster(m_pEnemy, nHeroType, prizeBarrel, nExp, m_nPassivePrizeMonsterProbModifier + nMonsterProbModifier, x, y, z);
		}
    }

	int m_nDefinedPrize;

	function unitex CreateDefinedPrize(int x, int y, int z, int a, string strUnitName, string strPrizeName)
	{
		unitex uUnit;

		uUnit = m_pEnemy.CreateUnit(x, y, z, a, strUnitName);
		SetStringBuff(bufferPrizeNames+m_nDefinedPrize, strPrizeName);

		uUnit.SetScriptData(maskDefinedPrize|m_nDefinedPrize);

		++m_nDefinedPrize;

		return uUnit;
	}
	function unitex CreateChest(int x, int y, int z, int a, string strPrizeName)
	{
		int nTmp;
		unitex uChest;

		nTmp = RAND(3);
		if ( nTmp == 0 ) uChest = CreateDefinedPrize(x, y, z, a, "CHEST1", strPrizeName);
		if ( nTmp == 1 ) uChest = CreateDefinedPrize(x, y, z, a, "CHEST2", strPrizeName);
		if ( nTmp == 2 ) uChest = CreateDefinedPrize(x, y, z, a, "CHEST3", strPrizeName);

		uChest.CommandSetMovementMode(modeHoldPos);

		return uChest;
	}
	function unitex CreateChestAtMarker(int nMarker, string strPrizeName)
	{
		return CreateChest(GetPointX(nMarker), GetPointY(nMarker), GetPointZ(nMarker), RAND(0x100), strPrizeName);
	}

	event UnitDestroyed(unitex uUnit)
	{
		player pPlayer;
		int x, y, z;
		int nIFFNum;
		int nAnimals;
		unit uAttacker;
		int nExp;
		int i, n;
		int iQuest;
		platoon platTmp;
		int nPrizeType;
		int nPrize;

		unitex uHero;

		int nHeroType;

		if ( uUnit.GetIFF() != m_pEnemy.GetIFF() ) return;

		uAttacker = uUnit.GetAttacker();

		uHero = GetUnitExRef(uAttacker);

		#ifdef RPG_X_EC
			if ( RPGX_UnitDestroyed(uUnit, uHero) )
			{
				return;
			}
		#endif RPG_X_EC

		x = uUnit.GetLocationX();
		y = uUnit.GetLocationY();
		z = uUnit.GetLocationZ();
		
		if ( uUnit.GetScriptData() == 777 )
		{
			if ( IsUnitInArray(m_auHero, uHero) )
			{
				CreateBonusItem(uHero, x, y, z);

				OnBonusDoneExpAdd(uHero);
			}
			else
			{
				CreateBonusItem(null, x, y, z);
			}

			return;
		}
		else if ( uUnit.GetScriptData() == 797 )
		{
			if ( IsUnitInArray(m_auHero, uHero) )
			{
				CreateGold(uHero, x, y, z);
			}
			else
			{
				CreateGold(null, x, y, z);
			}

			return;
		}

		if ( uUnit.GetScriptData() & maskDefinedPrize )
		{
			nPrize = uUnit.GetScriptData() & ~maskDefinedPrize;

			CreateArtefactAtUnit(GetStringBuff(bufferPrizeNames+nPrize), uUnit, 0);
		}

		n = m_anQuestActive.GetSize();
		for (i=0; i<n; ++i)
		{
			iQuest = m_anQuestActive[i];
			if ( m_anQuestType[iQuest] == questKillBring )
			{
				platTmp = m_apEnemy[iQuest];
				if ( platTmp.InPlatoon(uUnit.GetUnitRef()) )
				{
					CreateArtefactAtUnit(GetStringBuff(bufferBringArts+iQuest), uUnit, 0);
				}
			}
		}

		// if ( comboRespawnMonsters )
		// {
			nAnimals = m_pEnemy.GetNumberOfUnits(x, y, z, 3);
			
			if ( nAnimals == 1 ) // tylko zabity
			{
				if ( RAND(m_nRespawnOneOf) == 0 )
				{
					m_anKilledX.Add(x);
					m_anKilledY.Add(y);
					m_anKilledZ.Add(z);
				}
			}
		// }

		if ( IsUnitInArray(m_auHero, uHero) )
		{
			nExp = uHero.GetExperienceLevel();
			nHeroType = 1 << (uHero.GetRPGCharacterType()-1);
		}
		else
		{
			n = m_auHero.GetSize();
			for (i=0; i<n; ++i)
			{
				uHero = m_auHero[i];

				if (uHero != null)
				{
					nHeroType = nHeroType | (1 << (uHero.GetRPGCharacterType()-1));
					if ( uHero.GetExperienceLevel() > nExp ) nExp = uHero.GetExperienceLevel();
				}
			}

			uHero = null;
		}

#ifdef RPG_DEMO
		if ( nExp > RPG_DEMO_MAX_EXP ) nExp = RPG_DEMO_MAX_EXP;
#endif

		nPrizeType = uUnit.GetScriptParam();

		if ( uHero != null )
		{
			CreatePrize       (          nHeroType, nPrizeType, nExp,  uHero.GetRPGSkillArtefacts(), x, y, z);
			CreatePrizeMonster(m_pEnemy, nHeroType, nPrizeType, nExp, -uHero.GetRPGSkillArtefacts(), x, y, z);
		}
		else
		{
			CreatePrize       (          nHeroType, nPrizeType, nExp, 0, x, y, z);
			CreatePrizeMonster(m_pEnemy, nHeroType, nPrizeType, nExp, 0, x, y, z);
		}
	}
	
	event Timer0()
	{
		player rPlayer;
		unitex uHero;
		int i, n;

		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];
			if ((uHero != null) && !uHero.IsLive() && !uHero.IsInWorld())
			{
				// CreateObject(uHero.GetLocationX(), uHero.GetLocationY(), uHero.GetLocationZ(), RAND(0x100), "HERO_DEAD");

				uHero.SaveDeadRPGCharacter();
				rPlayer = GetPlayer(uHero.GetIFFNumber());
				rPlayer.LookAt(uHero.GetLocationX(), uHero.GetLocationY(), constLookAtHeight, constLookAtAlpha, constLookAtView, uHero.GetLocationZ());
				rPlayer.ShowRecreateRPGCharacterDialog();

				m_auHero.RemoveAt(i);
				--i; --n;
			}
		}
	}
	
	event Timer1()
	{
		int i, n;

		n = m_auShop.GetSize();
		for (i=0; i<n; ++i)
		{
			UpdateShop(m_auShop[i]);
		}
	}

    event Timer4()
    {
		if ( RAND(100) < 10 ) // 10 %
		{
			if ( GetCurrentTerrainNum() == 5 ) // zima
			{
				Snow((GetLeft() + GetRight())/2, (GetTop() + GetBottom())/2, 128, 100, 1000, 100, 5+Rand(6));
			}
			else if ( Rand(5) == 0 )
			{
				Rain((GetLeft() + GetRight())/2, (GetTop() + GetBottom())/2, 128, 100, 1000, 100, 5+Rand(6));
			}
		}
	}

	event Timer7()
	{
		StartWind();
	}

#if   defined(RPG_X_EC)
#include     "RPG_X.ech"
#endif
#if   defined(RPG_1_EC)
#include     "RPG_1.ech"
#elif defined(RPG_2_EC)
#include     "RPG_2.ech"
#elif defined(RPG_3_EC)
#include     "RPG_3.ech"
#elif defined(RPG_4_EC)
#include     "RPG_4.ech"
#elif defined(RPG_5_EC)
#include     "RPG_5.ech"
#elif defined(RPG_6_EC)
#include     "RPG_6.ech"
#elif defined(RPG_7_EC)
#include     "RPG_7.ech"
#elif defined(RPG_8_EC)
#include     "RPG_8.ech"
#endif

	event RecreateRPGCharacter(int nIFFNum)
	{
		player rPlayer;
		int nQuest;

		unitex uHero;
		
		rPlayer = GetPlayer(nIFFNum);

		if ( IsRespawnSafe(nIFFNum) )
		{
			uHero = rPlayer.CreateRPGCharacter(m_anPlayerRespawnX[nIFFNum], m_anPlayerRespawnY[nIFFNum], m_anPlayerRespawnZ[nIFFNum], 0);
		}
		else
		{
			uHero = rPlayer.CreateRPGCharacter(rPlayer.GetStartingPointX(), rPlayer.GetStartingPointY(), 0, 0);
		}

		m_anPlayerHeroX[nIFFNum] = uHero.GetLocationX();
		m_anPlayerHeroY[nIFFNum] = uHero.GetLocationY();
		m_anPlayerHeroZ[nIFFNum] = uHero.GetLocationZ();

		CreateObjectAtUnit(uHero, "REVIVE_HERO_EFFECT");

		m_auHero.Add(uHero);
		rPlayer.LookAt(uHero.GetLocationX(), uHero.GetLocationY(), constLookAtHeight, constLookAtAlpha, constLookAtView, uHero.GetLocationZ());

		nQuest = m_anPlayerQuest[nIFFNum];

		if ( IsIntInArray(m_anQuestActive, nQuest) )
		{
			m_auQuestHero[nQuest] = uHero;
		}
		else if ( IsIntInArray(m_anQuestDone, nQuest) )
		{
			m_auQuestHero[nQuest] = uHero;
		}
		else
		{
			m_auHeroReady.Add(uHero);
		}
	}

    event NewDynamicConnectionPlayer(int nIFFNum)
    {
        int i;
        player rPlayer, p2;
        unitex uDepot;

		rPlayer=GetPlayer(nIFFNum);
		for(i=0;i<8;i=i+1)
		{
            if (i != nIFFNum)
            {
			    p2 = GetPlayer(i);
			    if ( p2 != null )
			    {
                    if (p2.IsAlive() && (!rPlayer.IsNeutral(p2) || !p2.IsNeutral(rPlayer)))
                    {
				        SetNeutrals(rPlayer, p2);
                    }
				}
			}
		}
        if (PointExist("MARKER_CHEST_DEPOT", nIFFNum))
        {
            uDepot = m_auHeroDepot[nIFFNum];
            if ((uDepot != null) && !uDepot.IsInWorld())
            {
                m_auHeroDepot[nIFFNum] = null;
            }
            m_auHeroDepot[nIFFNum] = rPlayer.CreateDepot(m_auHeroDepot[nIFFNum], "CHEST_DEPOT", GetPointX("MARKER_CHEST_DEPOT", nIFFNum), GetPointY("MARKER_CHEST_DEPOT", nIFFNum), GetPointZ("MARKER_CHEST_DEPOT", nIFFNum), GetPointAlpha("MARKER_CHEST_DEPOT", nIFFNum));
        }
	    m_anPlayerHeroX[nIFFNum] = rPlayer.GetStartingPointX();
	    m_anPlayerHeroY[nIFFNum] = rPlayer.GetStartingPointY();
	    m_anPlayerHeroZ[nIFFNum] = 0;
		m_anPlayerRespawnX[nIFFNum] = -1;
		m_anPlayerRespawnY[nIFFNum] = -1;
		m_anPlayerRespawnZ[nIFFNum] = -1;
        rPlayer.SetScriptData(dataHeroExp, 0);
        //goals
        m_anPlayerLastGoal[nIFFNum] = 0;
        m_anPlayerQuest[nIFFNum] = -1;
        m_anPlayerQuestsDone[nIFFNum] = 0;
	#ifndef RPG_X_EC
		if ( m_anQuestReady.GetSize() > 0 )
		{
			rPlayer.RegisterGoal(goalFindQuest, "translateGoalFindQuestRPG", m_anQuestReady.GetSize());
            rPlayer.EnableGoal(goalFindQuest, true);
		}
		else
		{
			rPlayer.EnableGoal(goalFindQuest, false);
		}
    #endif

	#ifdef RPG_X_EC
		RPGX_NewDynamicConnectionPlayer(nIFFNum);
	#endif RPG_X_EC
    }
	
    event OpenRPGShop(unitex uHero, unitex uShop)
    {
		if ( IsUnitInArray(m_auHero, uHero) )
		{
			SetRespawnHere(uHero);
		}

        return true;
    }

	event EndMission()
	{
		int i, n;
		unitex uHero;

		n = m_auHero.GetSize();
		for (i=0; i<n; ++i)
		{
			uHero = m_auHero[i];

			if (uHero != null)
			{
				uHero.SaveRPGCharacter(true, true, true);
			}
		}
	}
	
	event RemoveResources()
	{
		return false;
	}
	
	event RemoveUnits()
	{
		return false;
	}
	
	event UseExtraSkirmishPlayers()
	{
		return true;
	}
	
	event SpecialLevelFlags()
	{
		return 0x04;
	}
	
	event AIPlayerFlags()
	{
		return 0;
	}
	
	event CheckValidRPGLevel()
	{
		int i;
		int nPlayers;

		if ( GetPlayer( 8) == null ) return false;
		if ( GetPlayer( 9) == null ) return false;
		if ( GetPlayer(10) == null ) return false;

		nPlayers = 0;
		for ( i=0; i<constMaxPlayers; ++i )
		{
			if ( GetPlayer(i) != null ) ++nPlayers;
		}

		if ( nPlayers < 2 ) return false;

		return true;
	}
	
	event SetupInterface()
	{
		SetInterfaceOptions(
			//	        lockResearchDialog |
			//	        lockConstructionDialog |
			//	        lockUpgradeWeaponDialog |
			//            lockAllianceDialog |
			lockGiveMoneyDialog |
			lockGiveUnitsDialog |
			//            lockShowToolbar |
			//            lockToolbarMap |
			//            lockToolbarPanel |
			lockToolbarSwitchMode |
			lockToolbarLevelName |
			//            lockToolbarTunnels |
			//            lockToolbarObjectives |
			//            lockToolbarResearching |
			//            lockToolbarConstruction |
			//            lockToolbarMenu |
			lockToolbarMoney |
			//            lockDisplayToolbarLevelName |
			lockDisplayToolbarMoney |
			lockCreateBuildPanel |
			//            lockCreateMoneyProgress |
			0);
	}
	
	command InitializeLoad()
	{
		ReplaceLoadObjects();

		return true;
	}
	
	command Initialize()
	{
        comboDropSubObjects = 1;
		return true;
	}
	
	command Uninitialize()
	{
		return true;
	}
	
	command Combo1(int nMode) button comboRespawnMonsters
	{
		comboRespawnMonsters = nMode;
		return true;
	}
	command Combo2(int nMode) button comboDropSubObjects
	{
		comboDropSubObjects = nMode;
		return true;
	}
	/*
	command Combo2(int nMode) button comboQuestsDifficulty
	{
		comboQuestsDifficulty = nMode;
		return true;
	}
	/**/
}
