# Lordshift (aka Knightshift 2: Curse of Souls or Polanie III) Alpha 0.1

"Lordshift" was supposed to be an expansion/sequel to Knightshift, built upon the same game engine. It would have focused on a single player RPG campaign, expanded upon the action RPG gameplay, and not have an RTS mode.

The project was abandoned in favor of "Two Worlds".

## Content

This is not a playable game. This version only contains:

- A slightly modified engine, which supports a few more parameters for specifying character skills & items. Unfortunately, the complete list of changes has been lost. Maybe some things can be deduced from how the parameter Excel sheet differs from the base game's parameters. 
- A lot of ugly programmer art.
- Updated game parameters for some of the monsters, characters & skills the game would have had.

## Installation

1. Install Knightshift from disk (the GOG version doesn't appear to work) and update to patch version 1.2.
2. Copy the folder on top of the installed files.
3. Edit "Lordshift Registry.reg" so that the pathes match the directory of the installation and execute it.
4. The file "Serials_LS_forTest" contains a list of serial keys accepted by the alpha version.
